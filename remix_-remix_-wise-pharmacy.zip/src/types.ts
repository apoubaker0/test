export interface PrescriptionRequest {
  id: string;
  patientName: string;
  dob: string;
  nhsNumber?: string;
  phone: string;
  email: string;
  medicationDetails: string;
  isDelivery: boolean;
  deliveryAddress?: string;
  status: 'Pending' | 'Reviewing' | 'Preparing' | 'Ready for Collection' | 'Out for Delivery' | 'Completed' | 'Action Required';
  statusNotes?: string;
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  createdAt: string;
  replied: boolean;
  replyText?: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  text: string;
  tag?: string;
}

export interface PharmacyService {
  id: string;
  title: string;
  description: string;
  type: 'NHS' | 'Private' | 'Free Service';
  iconName: string;
  details: string[];
}

export interface StaffMember {
  name: string;
  role: string;
  credentials?: string;
  bio: string;
  imageSeed: string;
}
