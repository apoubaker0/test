import { PharmacyService, StaffMember, Review } from '../types';

export const servicesData: PharmacyService[] = [
  {
    id: 'dispensing',
    title: 'NHS & Private Prescription Dispensing',
    description: 'Accurate and timely dispensing of your daily medications with comprehensive pharmacist review.',
    type: 'NHS',
    iconName: 'Pill',
    details: [
      'Electronic Prescription Service (EPS) supported',
      'Detailed medicine use reviews with our pharmacist',
      'Advice on newly prescribed medications',
      'Safe disposal of unwanted or expired medicines'
    ]
  },
  {
    id: 'repeat',
    title: 'Electronic Repeat Prescriptions',
    description: 'We manage your regular prescriptions with your local GP surgery so you never run out.',
    type: 'Free Service',
    iconName: 'RefreshCw',
    details: [
      'Automatic sync with your local Manchester GP',
      'Reminders when your next batch is ready to order',
      'Submit requests easily online through our Patient Care Hub',
      'Hassle-free setup'
    ]
  },
  {
    id: 'delivery',
    title: 'Free Home Delivery Service',
    description: 'Reliable, tracked delivery of medications to your doorstep in Manchester, handled with patient care first.',
    type: 'Free Service',
    iconName: 'Truck',
    details: [
      'Serving Rusholme, Victoria Park, Fallowfield, and surrounding areas',
      'Interactive SMS or call notification prior to delivery to ensure you are home',
      'Trained drivers who wait patiently for you to answer',
      'Temperature-sensitive and secure transport protocols'
    ]
  },
  {
    id: 'consultations',
    title: 'Pharmacist Consultations',
    description: 'Private, confidential clinical advice on minor illnesses, medication concerns, and healthy living.',
    type: 'NHS',
    iconName: 'MessageSquareHeart',
    details: [
      'Private consultation room available in-store',
      'NHS Pharmacy First service for minor conditions',
      'No appointment necessary — just walk in and ask',
      'Warm, friendly, and non-judgmental professional advice'
    ]
  },
  {
    id: 'flu_jabs',
    title: 'NHS Flu & COVID Vaccinations',
    description: 'Protect yourself and your family with our seasonal vaccination clinics administered by experts.',
    type: 'NHS',
    iconName: 'ShieldAlert',
    details: [
      'Free NHS jabs for eligible patients',
      'Convenient booking or walk-in service',
      'Safe, hygienic, and highly gentle administration',
      'Corporate/employer vaccination schemes available'
    ]
  },
  {
    id: 'health_checks',
    title: 'Heart & Blood Pressure Checks',
    description: 'Routine screening services to help you monitor your vital health indicators and prevent disease.',
    type: 'NHS',
    iconName: 'HeartPulse',
    details: [
      'NHS Blood Pressure Check service',
      'Immediate results and action plans if required',
      'Lifestyle and dietary guidance to support your heart',
      'Referrals to local GPs when clinical follow-up is needed'
    ]
  }
];

export const staffData: StaffMember[] = [
  {
    name: 'Mr. Zahid Hussain',
    role: 'Lead Pharmacist & Pharmacy Director',
    credentials: 'MPharm, MRPharmS',
    bio: 'With over 15 years of experience serving the Manchester community, Zahid is dedicated to patient-centric clinical care. He is known for his unmatched patience, gentle guidance, and ensuring that every patient leaves fully understanding their treatment plan.',
    imageSeed: 'zahid'
  },
  {
    name: 'Sarah Jenkins',
    role: 'Senior Dispensing Technician',
    credentials: 'NVQ Level 3 Pharmacy Services',
    bio: 'Sarah oversees the dispensing team, ensuring the highest standards of safety and accuracy. She specializes in organizing multi-compartment compliance aids (dosette boxes) and is always ready with a warm, comforting smile for our regular patients.',
    imageSeed: 'sarah'
  },
  {
    name: 'Michael Thompson',
    role: 'Patient Care & Dedicated Delivery Coordinator',
    bio: 'Michael coordinates our community delivery service. Having lived in Rusholme all his life, Michael takes pride in delivering with a friendly word and immense patience, making sure seniors and vulnerable patients never feel rushed or missed.',
    imageSeed: 'michael'
  }
];

export const reviewsData: Review[] = [
  {
    id: '1',
    author: 'Eleanor Vance',
    rating: 5,
    date: 'June 2026',
    text: 'The pharmacist here is exceptionally professional and patient. He took 20 minutes to explain how to use my new inhaler correctly and put all my anxieties at ease. Simply the best local service.',
    tag: 'Pharmacist Service'
  },
  {
    id: '2',
    author: 'David Harrison',
    rating: 5,
    date: 'May 2026',
    text: 'I had issues with missed deliveries from online pharmacies, but Wise Pharmacy has been amazing. They call before they arrive and the driver actually waits for me to get to the door. Extremely trustworthy.',
    tag: 'Home Delivery'
  },
  {
    id: '3',
    author: 'Yasmin Begum',
    rating: 5,
    date: 'April 2026',
    text: 'They always treat my elderly mother with so much dignity and respect. The NHS Pharmacy First consultation saved us a trip to the GP. Highly recommended for their warmth and care.',
    tag: 'Patient Dignity'
  }
];

export const openingHours = {
  weekdays: '09:00 - 18:00',
  saturday: '09:00 - 13:00',
  sunday: 'Closed',
  address: '11 Anson Rd, Manchester M14 5BY, United Kingdom',
  phone: '+44 161 224 1878',
  email: 'care@wisepharmacymanchester.co.uk'
};
