import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Pill, RefreshCw, FileText, CheckCircle, Info, Calendar, User, Phone, Mail, Home, AlertCircle, ChevronDown, Check, Clock, Search, HelpCircle, Eye
} from 'lucide-react';
import { PrescriptionRequest } from '../types';

interface PatientPortalProps {
  highContrast: boolean;
  textSize: string;
  onNewPrescriptionSubmitted: () => void; // Notify other components (like Pharmacist portal) to sync
}

export default function PatientPortal({ highContrast, textSize, onNewPrescriptionSubmitted }: PatientPortalProps) {
  const [activeSubTab, setActiveSubTab] = useState<'request' | 'my-requests'>('request');
  const [requests, setRequests] = useState<PrescriptionRequest[]>([]);
  
  // Form fields
  const [patientName, setPatientName] = useState('');
  const [dob, setDob] = useState('');
  const [nhsNumber, setNhsNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [medicationDetails, setMedicationDetails] = useState('');
  const [isDelivery, setIsDelivery] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [authorized, setAuthorized] = useState(false);
  const [gpSurgery, setGpSurgery] = useState('');
  
  // Feedback
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load from local storage
  useEffect(() => {
    const saved = localStorage.getItem('wise_pharmacy_prescriptions');
    if (saved) {
      setRequests(JSON.parse(saved));
    } else {
      // Seed initial dummy requests so it doesn't look empty and gives a nice flow
      const dummy: PrescriptionRequest[] = [
        {
          id: 'RX-82741',
          patientName: 'Patricia Jenkins',
          dob: '1952-11-20',
          nhsNumber: '485 928 3749',
          phone: '0161 555 0192',
          email: 'patricia@jenkins-manchester.co.uk',
          medicationDetails: 'Atorvastatin 20mg - 1 daily, Amlodipine 5mg - 1 daily',
          isDelivery: true,
          deliveryAddress: '22 Anson Rd, Manchester, M14 5BZ',
          status: 'Ready for Collection',
          statusNotes: 'Your prescription has been dispensed by Sarah and is ready for collection or dispatch. Michael will contact you shortly.',
          createdAt: new Date(Date.now() - 36 * 3600000).toISOString() // 36 hours ago
        },
        {
          id: 'RX-55102',
          patientName: 'Patricia Jenkins',
          dob: '1952-11-20',
          nhsNumber: '485 928 3749',
          phone: '0161 555 0192',
          email: 'patricia@jenkins-manchester.co.uk',
          medicationDetails: 'Omeprazole 20mg gastro-resistant capsules - 1 daily',
          isDelivery: true,
          deliveryAddress: '22 Anson Rd, Manchester, M14 5BZ',
          status: 'Completed',
          statusNotes: 'Hand-delivered with care by Michael Thompson. Signature acquired.',
          createdAt: new Date(Date.now() - 7 * 24 * 3600000).toISOString() // 7 days ago
        }
      ];
      localStorage.setItem('wise_pharmacy_prescriptions', JSON.stringify(dummy));
      setRequests(dummy);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    // Validate
    if (!patientName.trim() || !dob || !phone.trim() || !email.trim() || !medicationDetails.trim() || !gpSurgery.trim()) {
      setErrorMessage('Please fill in all the required fields. We need this information to process your prescription safely.');
      return;
    }

    if (isDelivery && !deliveryAddress.trim()) {
      setErrorMessage('Please specify your home address for prescription delivery.');
      return;
    }

    if (!authorized) {
      setErrorMessage('Please authorize Wise Pharmacy to coordinate with your GP surgery by ticking the consent box.');
      return;
    }

    const newRequest: PrescriptionRequest = {
      id: `RX-${Math.floor(10000 + Math.random() * 90000)}`,
      patientName,
      dob,
      nhsNumber: nhsNumber.trim() || undefined,
      phone,
      email,
      medicationDetails: `${medicationDetails} (GP Surgery: ${gpSurgery})`,
      isDelivery,
      deliveryAddress: isDelivery ? deliveryAddress : undefined,
      status: 'Pending',
      statusNotes: 'Your request is in our system. Zahid Hussain is reviewing your clinical profile to request GP authorization.',
      createdAt: new Date().toISOString()
    };

    const updated = [newRequest, ...requests];
    localStorage.setItem('wise_pharmacy_prescriptions', JSON.stringify(updated));
    setRequests(updated);

    // Clear fields
    setPatientName('');
    setDob('');
    setNhsNumber('');
    setPhone('');
    setEmail('');
    setMedicationDetails('');
    setGpSurgery('');
    setIsDelivery(false);
    setDeliveryAddress('');
    setAuthorized(false);

    setSuccessMessage(`Prescription Request ${newRequest.id} successfully submitted! Zahid and the team are reviewing it. You can track this request on the "My Requests Tracker" tab.`);
    setActiveSubTab('my-requests');
    onNewPrescriptionSubmitted(); // Notify parent of database change
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending':
        return highContrast ? 'bg-zinc-800 text-yellow-400 border border-yellow-400' : 'bg-slate-100 text-slate-700';
      case 'Reviewing':
        return highContrast ? 'bg-zinc-900 text-blue-300 border border-blue-400' : 'bg-sky-50 text-sky-800 border border-sky-100';
      case 'Preparing':
        return highContrast ? 'bg-zinc-900 text-indigo-300 border border-indigo-400' : 'bg-indigo-50 text-indigo-800 border border-indigo-100';
      case 'Ready for Collection':
        return highContrast ? 'bg-zinc-950 text-green-400 border border-green-400' : 'bg-emerald-50 text-emerald-800 border border-emerald-100';
      case 'Out for Delivery':
        return highContrast ? 'bg-zinc-950 text-amber-400 border border-amber-400' : 'bg-amber-50 text-amber-800 border border-amber-100';
      case 'Completed':
        return highContrast ? 'bg-yellow-400 text-black font-black' : 'bg-green-100 text-green-900';
      case 'Action Required':
        return highContrast ? 'bg-red-950 text-red-300 border border-red-500 font-bold' : 'bg-red-50 text-red-800 border border-red-100';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <section 
      className={`w-full py-12 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-slate-50/20'
      }`}
      id="patient-portal-section"
    >
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10" id="portal-header">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide inline-block mb-3 ${
            highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'
          }`}>
            NHS Electronic Prescription Service (EPS)
          </span>
          <h2 className={`font-sans tracking-tight ${
            textSize === 'xlarge' ? 'text-4xl font-black' : textSize === 'large' ? 'text-3xl font-extrabold' : 'text-3xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
            Online Patient Care Hub
          </h2>
          <p className="text-xs mt-2 text-slate-500 dark:text-zinc-400 leading-relaxed">
            Order your repeat prescriptions online directly from Wise Pharmacy. We sync with your local GP surgery to handle everything safely on your behalf.
          </p>
        </div>

        {/* Portal Tabs Toggle */}
        <div className="flex border-b border-slate-200 dark:border-zinc-800 mb-8 max-w-md mx-auto" id="portal-tab-group">
          <button
            onClick={() => setActiveSubTab('request')}
            className={`flex-1 py-3 text-center text-sm font-extrabold transition-all relative ${
              activeSubTab === 'request'
                ? highContrast ? 'text-yellow-400 font-black border-b-4 border-yellow-400' : 'text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
            id="portal-tab-submit-request"
          >
            Submit Prescription Request
          </button>
          
          <button
            onClick={() => setActiveSubTab('my-requests')}
            className={`flex-1 py-3 text-center text-sm font-extrabold transition-all relative flex items-center justify-center gap-1.5 ${
              activeSubTab === 'my-requests'
                ? highContrast ? 'text-yellow-400 font-black border-b-4 border-yellow-400' : 'text-teal-700 border-b-2 border-teal-600'
                : 'text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
            id="portal-tab-track-request"
          >
            My Requests Tracker
            {requests.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'
              }`}>
                {requests.length}
              </span>
            )}
          </button>
        </div>

        {/* Dynamic Panel Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="portal-body-layout">
          
          {/* Main Workspace (Left - 8 Columns or 12 depending on context) */}
          <div className="lg:col-span-8" id="portal-workspace-column">
            
            <AnimatePresence mode="wait">
              {activeSubTab === 'request' ? (
                <motion.div
                  key="request-form"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className={`p-6 sm:p-8 rounded-3xl border-2 shadow-sm ${
                    highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-slate-100 bg-white'
                  }`}
                >
                  <h3 className={`font-sans font-black flex items-center gap-2 mb-6 ${
                    textSize === 'xlarge' ? 'text-2xl' : 'text-lg'
                  }`}>
                    <FileText className="w-5 h-5 text-teal-600 dark:text-yellow-400" />
                    New Prescription Order Form
                  </h3>

                  {successMessage && (
                    <div className="p-4 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-900 text-xs font-semibold mb-6 flex items-start gap-2.5">
                      <CheckCircle className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                      <span>{successMessage}</span>
                    </div>
                  )}

                  {errorMessage && (
                    <div className="p-4 rounded-xl bg-red-50 border border-red-100 text-red-900 text-xs font-semibold mb-6 flex items-start gap-2.5">
                      <AlertCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-6" id="prescription-request-form">
                    
                    {/* Section 1: Patient Identity */}
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-yellow-400 mb-4 pb-1 border-b">
                        1. Patient Identity
                      </h4>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-extrabold flex items-center gap-1">
                            <User className="w-3.5 h-3.5 opacity-60" />
                            Full Name <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Patricia Jenkins"
                            value={patientName}
                            onChange={(e) => setPatientName(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-extrabold flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 opacity-60" />
                            Date of Birth <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="date"
                            value={dob}
                            onChange={(e) => setDob(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5 sm:col-span-2">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-extrabold">
                              NHS Number <span className="text-slate-400 text-[10px] font-normal">(Optional but highly recommended)</span>
                            </label>
                            <span className="text-[10px] opacity-60 flex items-center gap-1">
                              <Info className="w-3 h-3" />
                              Found on prescriptions or NHS app
                            </span>
                          </div>
                          <input
                            type="text"
                            placeholder="e.g. 485 928 3749"
                            value={nhsNumber}
                            onChange={(e) => setNhsNumber(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 2: Contact Info */}
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-yellow-400 mb-4 pb-1 border-b">
                        2. Contact Information
                      </h4>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-extrabold flex items-center gap-1">
                            <Phone className="w-3.5 h-3.5 opacity-60" />
                            Phone Number <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="tel"
                            placeholder="e.g. 0161 555 0192"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-extrabold flex items-center gap-1">
                            <Mail className="w-3.5 h-3.5 opacity-60" />
                            Email Address <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="email"
                            placeholder="e.g. patricia@domain.co.uk"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 3: Medication details & GP Surgery */}
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-yellow-400 mb-4 pb-1 border-b">
                        3. Medication & GP Surgery details
                      </h4>
                      
                      <div className="space-y-4">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-xs font-extrabold">
                            GP Surgery / Practice Name <span className="text-red-500">*</span>
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Rusholme Health Centre, Anson Road Medical Practice"
                            value={gpSurgery}
                            onChange={(e) => setGpSurgery(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-extrabold">
                              Medication Names & Strengths <span className="text-red-500">*</span>
                            </label>
                            <span className="text-[10px] opacity-60">List each item separately</span>
                          </div>
                          <textarea
                            rows={3}
                            placeholder="e.g. Atorvastatin 20mg - 28 tablets (take 1 daily), Salbutamol Inhaler - 1 unit"
                            value={medicationDetails}
                            onChange={(e) => setMedicationDetails(e.target.value)}
                            className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                              highContrast
                                ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                            }`}
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 4: Delivery Selection */}
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-yellow-400 mb-4 pb-1 border-b">
                        4. Delivery Preference
                      </h4>

                      <div className="space-y-4">
                        <label className="flex items-start gap-3 cursor-pointer group" id="delivery-checkbox-wrapper">
                          <input
                            type="checkbox"
                            checked={isDelivery}
                            onChange={(e) => setIsDelivery(e.target.checked)}
                            className={`mt-1 h-5 w-5 rounded transition ${
                              highContrast 
                                ? 'accent-yellow-400 text-black border-zinc-700' 
                                : 'accent-teal-600 border-slate-300'
                            }`}
                          />
                          <div>
                            <span className="text-xs font-extrabold text-slate-800 dark:text-yellow-300 group-hover:underline">
                              Yes, I require free home delivery of my medications
                            </span>
                            <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">
                              Available to patients who live within our 3-mile radius coverage area. Note our missed-delivery rules to ensure safe transfer.
                            </p>
                          </div>
                        </label>

                        {isDelivery && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            className="flex flex-col gap-1.5 pl-8"
                          >
                            <label className="text-xs font-extrabold flex items-center gap-1">
                              <Home className="w-3.5 h-3.5 opacity-60" />
                              Home Delivery Address <span className="text-red-500">*</span>
                            </label>
                            <textarea
                              rows={2}
                              placeholder="e.g. 22 Anson Rd, Manchester, M14 5BZ"
                              value={deliveryAddress}
                              onChange={(e) => setDeliveryAddress(e.target.value)}
                              className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                                highContrast
                                  ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                                  : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                              }`}
                              required={isDelivery}
                            />
                          </motion.div>
                        )}
                      </div>
                    </div>

                    {/* Section 5: Authorization and Consent */}
                    <div className={`p-4 rounded-xl border ${
                      highContrast ? 'border-yellow-400 bg-zinc-950' : 'border-slate-200 bg-slate-50/55'
                    }`}>
                      <h4 className="text-xs font-extrabold mb-2 text-slate-900 dark:text-yellow-300">NHS Patient Authorization Request:</h4>
                      <label className="flex items-start gap-3 cursor-pointer" id="authorization-consent-wrapper">
                        <input
                          type="checkbox"
                          checked={authorized}
                          onChange={(e) => setAuthorized(e.target.checked)}
                          className={`mt-1 h-5 w-5 rounded transition ${
                            highContrast 
                              ? 'accent-yellow-400 text-black' 
                              : 'accent-teal-600'
                          }`}
                          required
                        />
                        <span className="text-[11px] leading-relaxed font-semibold">
                          I authorize Wise Pharmacy to manage and collect my Electronic Repeat Prescriptions from my nominated GP Surgery. I understand that my details are stored locally and will be handled securely in alignment with NHS clinical guidelines. <span className="text-red-500">*</span>
                        </span>
                      </label>
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className={`w-full py-4 rounded-xl font-extrabold text-sm shadow flex items-center justify-center gap-2 transition ${
                        highContrast
                          ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                          : 'bg-teal-600 text-white hover:bg-teal-700'
                      }`}
                      id="submit-prescription-request-btn"
                    >
                      <RefreshCw className="w-4 h-4 shrink-0 animate-spin-slow" />
                      Securely Submit Prescription Request
                    </button>

                  </form>
                </motion.div>
              ) : (
                <motion.div
                  key="my-requests"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-6"
                  id="my-requests-tab-content"
                >
                  <h3 className={`font-sans font-black flex items-center gap-2 ${
                    textSize === 'xlarge' ? 'text-2xl' : 'text-lg'
                  }`}>
                    <Clock className="w-5 h-5 text-teal-600 dark:text-yellow-400" />
                    Active Prescriptions History & Status
                  </h3>

                  {requests.length === 0 ? (
                    <div className={`p-8 text-center rounded-2xl border border-dashed ${
                      highContrast ? 'border-zinc-800' : 'border-slate-200'
                    }`} id="no-requests-banner">
                      <p className="text-xs text-slate-500 dark:text-zinc-400">
                        You have not submitted any prescription requests yet. Fill in the order form on the previous tab to start tracking your medicines!
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4" id="requests-history-list">
                      {requests.map((req) => (
                        <div
                          key={req.id}
                          className={`p-5 rounded-2xl border-2 transition ${
                            highContrast 
                              ? 'border-zinc-800 bg-black text-white hover:border-yellow-400' 
                              : 'border-slate-100 bg-white hover:shadow-sm'
                          }`}
                          id={`prescription-row-${req.id}`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dashed border-slate-100 pb-4 mb-4 dark:border-zinc-800">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-black">{req.id}</span>
                                <span className="text-[10px] opacity-50">| Requested on {new Date(req.createdAt).toLocaleDateString()}</span>
                              </div>
                              <h4 className="text-xs font-extrabold mt-1">Patient: {req.patientName} (DOB: {new Date(req.dob).toLocaleDateString()})</h4>
                            </div>
                            
                            {/* Status label */}
                            <span className={`px-2.5 py-1 rounded text-xs font-extrabold uppercase ${getStatusColor(req.status)}`}>
                              ● {req.status}
                            </span>
                          </div>

                          <div className="space-y-3">
                            <div className="text-xs">
                              <span className="font-bold uppercase tracking-wider text-[10px] opacity-60">Prescribed Medicine:</span>
                              <p className="font-semibold mt-1 text-slate-800 dark:text-zinc-200">{req.medicationDetails}</p>
                            </div>

                            {req.isDelivery && req.deliveryAddress && (
                              <div className="text-xs">
                                <span className="font-bold uppercase tracking-wider text-[10px] opacity-60">Home Delivery Destination:</span>
                                <p className="font-medium text-slate-600 dark:text-zinc-300 mt-0.5">📦 {req.deliveryAddress}</p>
                              </div>
                            )}

                            {req.statusNotes && (
                              <div className={`p-3 rounded-lg text-xs leading-relaxed ${
                                highContrast ? 'bg-zinc-900 border border-zinc-800' : 'bg-slate-50 text-slate-700'
                              }`}>
                                <span className="font-bold text-teal-800 dark:text-yellow-400">Pharmacist Update Notes:</span>
                                <p className="mt-1">{req.statusNotes}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                </motion.div>
              )}
            </AnimatePresence>

          </div>

          {/* Right Guide Block (4 Columns) */}
          <div className="lg:col-span-4 space-y-6" id="portal-guide-column">
            
            {/* Guide Card: How EPS works */}
            <div className={`p-6 rounded-3xl border-2 ${
              highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-slate-100 bg-white'
            }`} id="eps-guide-card">
              <h4 className="text-xs font-black uppercase tracking-wider text-teal-800 dark:text-yellow-400 flex items-center gap-1.5 mb-4">
                <HelpCircle className="w-4 h-4 shrink-0" />
                Prescription Request Loop
              </h4>

              <div className="space-y-4 text-xs" id="eps-steps">
                <div className="flex gap-3">
                  <span className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center font-bold text-[10px] ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-800'
                  }`}>
                    1
                  </span>
                  <div>
                    <h5 className="font-bold">You submit request</h5>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">Fill in details and GP surgery. We verify everything safely.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <span className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center font-bold text-[10px] ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-800'
                  }`}>
                    2
                  </span>
                  <div>
                    <h5 className="font-bold">GP Authorization</h5>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">Our pharmacist Zahid contacts your local GP for digital clinical release (24-48 hrs).</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <span className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center font-bold text-[10px] ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-800'
                  }`}>
                    3
                  </span>
                  <div>
                    <h5 className="font-bold">Dispensing Care</h5>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">We dispense medications with dual safety barcode verification.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <span className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center font-bold text-[10px] ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-800'
                  }`}>
                    4
                  </span>
                  <div>
                    <h5 className="font-bold">Delivery or Pick Up</h5>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">Pick up in store or await Michael's friendly doorstep delivery.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Helpline Reassurance */}
            <div className={`p-5 rounded-2xl text-center border ${
              highContrast ? 'border-zinc-800 bg-black' : 'bg-teal-50/50 border-teal-100/50'
            }`}>
              <h5 className="text-xs font-bold text-teal-950 dark:text-yellow-400">Need Immediate Help?</h5>
              <p className="text-[11px] text-slate-600 dark:text-zinc-300 mt-1 leading-relaxed">
                If you are running low on medications or are concerned, call our Manchester pharmacists immediately.
              </p>
              <a
                href="tel:+441612241878"
                className={`mt-3 py-2 px-4 rounded-lg font-bold text-xs inline-block shadow-sm ${
                  highContrast
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                    : 'bg-white text-slate-800 border hover:bg-slate-50'
                }`}
                id="portal-guide-call"
              >
                📞 Call 0161 224 1878
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
