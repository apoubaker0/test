import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, Phone, Mail, Clock, HelpCircle, CheckCircle, Send, AlertCircle, Sparkles
} from 'lucide-react';
import { openingHours } from '../data/pharmacyData';
import { ContactMessage } from '../types';

interface ContactLocationProps {
  highContrast: boolean;
  textSize: string;
  onNewMessageSubmitted: () => void; // Trigger sync in other panels
}

export default function ContactLocation({ highContrast, textSize, onNewMessageSubmitted }: ContactLocationProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccess(null);
    setError(null);

    if (!name.trim() || !email.trim() || !phone.trim() || !subject.trim() || !message.trim()) {
      setError('Please fill in all input boxes before sending.');
      return;
    }

    // Save to local storage
    const newMessage: ContactMessage = {
      id: `MSG-${Math.floor(1000 + Math.random() * 9000)}`,
      name,
      email,
      phone,
      subject,
      message,
      createdAt: new Date().toISOString(),
      replied: false
    };

    const saved = localStorage.getItem('wise_pharmacy_messages');
    const existing: ContactMessage[] = saved ? JSON.parse(saved) : [];
    const updated = [newMessage, ...existing];

    localStorage.setItem('wise_pharmacy_messages', JSON.stringify(updated));
    onNewMessageSubmitted();

    setName('');
    setEmail('');
    setPhone('');
    setSubject('');
    setMessage('');

    setSuccess(`Thank you, ${newMessage.name}! Your message has been sent directly to Lead Pharmacist Zahid Hussain and the Manchester care team. We will call or email you shortly.`);
  };

  return (
    <section 
      className={`w-full py-12 sm:py-16 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-white'
      }`}
      id="contact-location-section"
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12" id="contact-heading-block">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide inline-block mb-3 ${
            highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'
          }`}>
            We Are Here For You
          </span>
          <h2 className={`font-sans tracking-tight ${
            textSize === 'xlarge' ? 'text-4xl font-black' : textSize === 'large' ? 'text-3xl font-extrabold' : 'text-3xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
            Visit Us or Get In Touch
          </h2>
          <p className="text-xs mt-2 text-slate-500 dark:text-zinc-400 leading-relaxed">
            Conveniently located on Anson Road in Manchester, with free patient parking and comfortable access for pushchairs and wheelchairs.
          </p>
        </div>

        {/* Content Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="contact-body-grid">
          
          {/* Contact Details & Google Map (Left - 5 Columns) */}
          <div className="lg:col-span-5 space-y-6" id="contact-details-panel">
            
            {/* Quick Details Box */}
            <div className={`p-6 sm:p-8 rounded-3xl border-2 ${
              highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-slate-100 bg-slate-50/50 text-slate-800'
            }`} id="location-cards-container">
              
              <div className="space-y-6">
                
                {/* Address Row */}
                <div className="flex gap-4 items-start">
                  <div className={`p-2 rounded-lg shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'}`}>
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider opacity-60">Pharmacy Address</h4>
                    <p className="text-sm font-bold mt-1">{openingHours.address}</p>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 font-medium">Located near Rusholme & Victoria Park</p>
                  </div>
                </div>

                {/* Phone Row */}
                <div className="flex gap-4 items-start">
                  <div className={`p-2 rounded-lg shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'}`}>
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider opacity-60">Phone Line (Click-to-call)</h4>
                    <p className="text-sm font-bold mt-1">
                      <a href={`tel:${openingHours.phone.replace(/ /g, '')}`} className="hover:underline text-teal-700 dark:text-yellow-400 font-black">
                        0161 224 1878
                      </a>
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 font-medium">Call us during opening hours for fast pharmacy support</p>
                  </div>
                </div>

                {/* Email Row */}
                <div className="flex gap-4 items-start">
                  <div className={`p-2 rounded-lg shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'}`}>
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider opacity-60">Clinical Email</h4>
                    <p className="text-sm font-bold mt-1">
                      <a href={`mailto:${openingHours.email}`} className="hover:underline text-teal-700 dark:text-yellow-400 font-semibold">
                        {openingHours.email}
                      </a>
                    </p>
                  </div>
                </div>

                {/* Opening Hours Box */}
                <div className="flex gap-4 items-start">
                  <div className={`p-2 rounded-lg shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'}`}>
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider opacity-60">Pharmacy Opening Hours</h4>
                    <div className="text-xs font-bold mt-1.5 space-y-1.5">
                      <div className="flex justify-between gap-6">
                        <span className="opacity-70">Monday - Friday:</span>
                        <span>09:00 - 18:00</span>
                      </div>
                      <div className="flex justify-between gap-6">
                        <span className="opacity-70">Saturday:</span>
                        <span>09:00 - 13:00</span>
                      </div>
                      <div className="flex justify-between gap-6 text-red-500 dark:text-red-400 font-extrabold">
                        <span className="opacity-70">Sunday:</span>
                        <span>Closed</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Embedded Google Map */}
            <div className={`rounded-3xl overflow-hidden border-2 h-[260px] shadow-sm relative ${
              highContrast ? 'border-yellow-400' : 'border-slate-100'
            }`} id="google-maps-box">
              <iframe
                title="Google Map location of Wise Pharmacy at 11 Anson Rd, Manchester"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2375.9261053422477!2d-2.221568284157832!3d53.45239107999863!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487bb16110f277bd%3A0xe54df97621f35ab7!2s11%20Anson%20Rd%2C%20Manchester%20M14%205BY%2C%20UK!5e0!3m2!1sen!2sus!4v1652199000000!5m2!1sen!2sus"
                className="w-full h-full border-0"
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                id="maps-iframe"
              ></iframe>
            </div>

          </div>

          {/* Simple Contact Form (Right - 7 Columns) */}
          <div className="lg:col-span-7" id="contact-form-panel">
            
            <div className={`p-6 sm:p-8 rounded-3xl border-2 shadow-sm ${
              highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-slate-100 bg-white'
            }`}>
              
              <h3 className={`font-sans font-black flex items-center gap-2 mb-6 ${
                textSize === 'xlarge' ? 'text-2xl' : 'text-lg'
              }`}>
                <HelpCircle className="w-5 h-5 text-teal-600 dark:text-yellow-400 animate-pulse" />
                Send a Direct Message to Our Pharmacist
              </h3>

              {success && (
                <div className="p-4 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-900 text-xs font-semibold mb-6 flex items-start gap-2.5">
                  <CheckCircle className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                  <span>{success}</span>
                </div>
              )}

              {error && (
                <div className="p-4 rounded-xl bg-red-50 border border-red-100 text-red-900 text-xs font-semibold mb-6 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-red-700 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4" id="direct-contact-form">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-extrabold">Your Full Name <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      placeholder="e.g. Ronald Fletcher"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                        highContrast
                          ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                          : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                      }`}
                      required
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-extrabold">Your Phone Number <span className="text-red-500">*</span></label>
                    <input
                      type="tel"
                      placeholder="e.g. 07700 900077"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                        highContrast
                          ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                          : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                      }`}
                      required
                    />
                  </div>

                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-extrabold">Your Email Address <span className="text-red-500">*</span></label>
                  <input
                    type="email"
                    placeholder="e.g. ronald.fletcher@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                      highContrast
                        ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                        : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                    }`}
                    required
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-extrabold">Subject / Inquiry Type <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    placeholder="e.g. NHS Flu Vaccine walk-in info, Prescription dispatch time"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                      highContrast
                        ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                        : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                    }`}
                    required
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-extrabold">Your Message <span className="text-red-500">*</span></label>
                  <textarea
                    rows={4}
                    placeholder="Describe how Zahid and our community care team can help you. We handle all clinical requests with absolute confidentiality and respect."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className={`p-3 rounded-lg border text-sm outline-none transition focus:ring-2 ${
                      highContrast
                        ? 'bg-black text-white border-zinc-700 focus:ring-yellow-400'
                        : 'bg-slate-50 border-slate-200 focus:bg-white focus:ring-teal-500/25 focus:border-teal-600'
                    }`}
                    required
                  />
                </div>

                {/* Send Button */}
                <button
                  type="submit"
                  className={`w-full py-3.5 rounded-xl font-extrabold text-sm shadow flex items-center justify-center gap-2 transition ${
                    highContrast
                      ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                      : 'bg-teal-600 text-white hover:bg-teal-700'
                  }`}
                  id="submit-message-btn"
                >
                  <Send className="w-4 h-4" />
                  Send Secure Message to Pharmacist
                </button>

              </form>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
