import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, CheckCircle2, Clock, AlertTriangle, MessageSquare, Save, Check, RefreshCcw, ShieldAlert, FileText, Mail, Phone, ChevronRight
} from 'lucide-react';
import { PrescriptionRequest, ContactMessage } from '../types';

interface PharmacistPortalProps {
  highContrast: boolean;
  textSize: string;
  refreshTrigger: number; // Used to trigger reload when forms submit on other pages
}

export default function PharmacistPortal({ highContrast, textSize, refreshTrigger }: PharmacistPortalProps) {
  const [prescriptions, setPrescriptions] = useState<PrescriptionRequest[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [selectedRx, setSelectedRx] = useState<PrescriptionRequest | null>(null);
  
  // Status editing state
  const [editStatus, setEditStatus] = useState<PrescriptionRequest['status']>('Pending');
  const [editNotes, setEditNotes] = useState('');
  
  // Message reply state
  const [replyText, setReplyText] = useState('');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);

  // Load from local storage
  const loadData = () => {
    const savedRx = localStorage.getItem('wise_pharmacy_prescriptions');
    if (savedRx) {
      setPrescriptions(JSON.parse(savedRx));
    }
    
    const savedMsg = localStorage.getItem('wise_pharmacy_messages');
    if (savedMsg) {
      setMessages(JSON.parse(savedMsg));
    } else {
      // Seed initial dummy contact messages
      const dummyMsg: ContactMessage[] = [
        {
          id: 'MSG-3921',
          name: 'Ronald Fletcher',
          email: 'ronald.fletcher@gmail.com',
          phone: '07700 900077',
          subject: 'NHS Flu Vaccine Clinic Saturday',
          message: 'Hello, do you have walk-in flu jabs available this Saturday morning? Or do I need to book in advance on the portal?',
          createdAt: new Date(Date.now() - 4 * 3600000).toISOString(),
          replied: false
        },
        {
          id: 'MSG-1102',
          name: 'Sarah Clough',
          email: 'sclough85@yahoo.co.uk',
          phone: '0161 222 3412',
          subject: 'Dosette Box Inquiry for Grandfather',
          message: 'My grandfather is moving to Rusholme and struggles to manage his complex medication schedule. Do you offer weekly blister packs or dosette boxes?',
          createdAt: new Date(Date.now() - 24 * 3600000).toISOString(),
          replied: true,
          replyText: 'Hello Sarah, yes we do! Our Senior Dispenser Sarah Jenkins specializes in setting up weekly multi-compartment compliance boxes (dosette boxes) for seniors. We can coordinate directly with his GP. Please bring his current prescription list or call us.'
        }
      ];
      localStorage.setItem('wise_pharmacy_messages', JSON.stringify(dummyMsg));
      setMessages(dummyMsg);
    }
  };

  useEffect(() => {
    loadData();
  }, [refreshTrigger]);

  const handleUpdateRx = (rxId: string) => {
    const updated = prescriptions.map(rx => {
      if (rx.id === rxId) {
        return {
          ...rx,
          status: editStatus,
          statusNotes: editNotes
        };
      }
      return rx;
    });

    localStorage.setItem('wise_pharmacy_prescriptions', JSON.stringify(updated));
    setPrescriptions(updated);
    setSelectedRx(null);
    alert('Prescription status updated successfully! The patient will see this status update on their tracker immediately.');
  };

  const handleReplyMessage = (msgId: string) => {
    if (!replyText.trim()) return;

    const updated = messages.map(msg => {
      if (msg.id === msgId) {
        return {
          ...msg,
          replied: true,
          replyText
        };
      }
      return msg;
    });

    localStorage.setItem('wise_pharmacy_messages', JSON.stringify(updated));
    setMessages(updated);
    setReplyText('');
    setSelectedMessage(null);
    alert('Reply stored successfully in local database simulation!');
  };

  const handleDeleteRx = (rxId: string) => {
    if (!confirm('Are you sure you want to remove this prescription request?')) return;
    const filtered = prescriptions.filter(rx => rx.id !== rxId);
    localStorage.setItem('wise_pharmacy_prescriptions', JSON.stringify(filtered));
    setPrescriptions(filtered);
    setSelectedRx(null);
  };

  return (
    <section 
      className={`w-full py-12 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-slate-900 text-slate-100'
      }`}
      id="pharmacist-portal"
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Portal Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-zinc-800" id="pharmacist-portal-header">
          <div>
            <span className={`px-2.5 py-1 rounded text-[10px] font-extrabold uppercase tracking-widest ${
              highContrast ? 'bg-yellow-400 text-black font-black' : 'bg-teal-500/20 text-teal-300'
            }`}>
              🔬 Administrative Clinical Simulation
            </span>
            <h2 className={`font-sans font-black tracking-tight mt-2 ${
              textSize === 'xlarge' ? 'text-3xl' : 'text-2xl'
            } ${highContrast ? 'text-yellow-400' : 'text-white'}`}>
              Wise Pharmacy Management Hub
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Role: Registered Pharmacist (Zahid Hussain). Manage repeat prescription dispensaries and patient messages.
            </p>
          </div>

          <button
            onClick={loadData}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
              highContrast 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white'
            }`}
            id="pharmacist-refresh-btn"
          >
            <RefreshCcw className="w-3.5 h-3.5" />
            Sync Database
          </button>
        </div>

        {/* Info Disclaimer Banner */}
        <div className={`p-4 rounded-xl border flex items-start gap-3 text-xs leading-relaxed mb-8 ${
          highContrast ? 'border-yellow-400/50 bg-zinc-950 text-zinc-300' : 'border-zinc-800 bg-zinc-950 text-zinc-400'
        }`} id="simulated-dashboard-banner">
          <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-extrabold text-amber-400">Simulation Dashboard Reminder:</span>
            <p className="mt-1">
              This special portal acts as the internal admin panel for the pharmacy. In a full production setup, this would be behind a secure pharmacist passcode lock. Here, you can act as Zahid Hussain, change order statuses (e.g. mark as "Ready for Collection" or "Out for Delivery"), and see how the Patient Hub updates instantly in real-time.
            </p>
          </div>
        </div>

        {/* Main Workspace Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="pharmacist-workspace-grid">
          
          {/* Active Orders List (Left Col - 7 columns) */}
          <div className="lg:col-span-7 space-y-6" id="pharmacist-orders-panel">
            <h3 className="font-sans font-black text-sm uppercase tracking-wider text-teal-400 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Prescription Orders Dispensing Queue ({prescriptions.length})
            </h3>

            {prescriptions.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-zinc-800 rounded-2xl bg-zinc-950" id="pharmacist-rx-empty">
                <p className="text-xs text-zinc-500">No submitted orders in the dispensing queue.</p>
              </div>
            ) : (
              <div className="space-y-4" id="pharmacist-orders-list">
                {prescriptions.map((rx) => (
                  <div
                    key={rx.id}
                    onClick={() => {
                      setSelectedRx(rx);
                      setEditStatus(rx.status);
                      setEditNotes(rx.statusNotes || '');
                    }}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                      selectedRx?.id === rx.id
                        ? highContrast
                          ? 'border-yellow-400 bg-zinc-900 text-white'
                          : 'border-teal-500 bg-zinc-950/80 text-white shadow-lg shadow-teal-500/5'
                        : 'border-zinc-800 bg-zinc-950 text-zinc-300 hover:border-zinc-700'
                    }`}
                    id={`pharmacist-rx-item-${rx.id}`}
                  >
                    <div className="flex justify-between items-start gap-4 border-b border-zinc-900 pb-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-white">{rx.id}</span>
                          <span className="text-[10px] text-zinc-500">
                            {new Date(rx.createdAt).toLocaleDateString()} at {new Date(rx.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold mt-1 text-zinc-200">Patient: {rx.patientName} (DOB: {new Date(rx.dob).toLocaleDateString()})</h4>
                      </div>
                      
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        rx.status === 'Completed' ? 'bg-green-500/20 text-green-300' :
                        rx.status === 'Ready for Collection' ? 'bg-emerald-500/20 text-emerald-300' :
                        rx.status === 'Out for Delivery' ? 'bg-amber-500/20 text-amber-300' : 'bg-zinc-800 text-zinc-300'
                      }`}>
                        {rx.status}
                      </span>
                    </div>

                    <div className="text-xs space-y-2">
                      <p className="font-medium text-zinc-400">💊 <span className="text-zinc-200">{rx.medicationDetails}</span></p>
                      
                      {rx.isDelivery && rx.deliveryAddress && (
                        <p className="text-xs text-amber-400">📦 Delivery requested: <span className="text-zinc-300">{rx.deliveryAddress}</span></p>
                      )}
                    </div>

                    {rx.statusNotes && (
                      <div className="mt-3 p-2 rounded bg-zinc-900 text-[11px] text-zinc-400 italic">
                        Notes: {rx.statusNotes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Panel for Prescriptions (Right Col - 5 columns) */}
          <div className="lg:col-span-5 space-y-6" id="pharmacist-action-panel">
            
            {/* Prescription Status Editor */}
            {selectedRx ? (
              <div className={`p-6 rounded-2xl border ${
                highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-zinc-800 bg-zinc-950 text-white'
              }`} id="prescription-editor-container">
                <h4 className="text-xs font-black uppercase tracking-wider text-teal-400 mb-4 flex items-center justify-between">
                  <span>Manage Prescription {selectedRx.id}</span>
                  <button 
                    onClick={() => setSelectedRx(null)} 
                    className="text-[10px] hover:underline"
                  >
                    Close
                  </button>
                </h4>

                <div className="space-y-4">
                  <div className="text-xs space-y-1">
                    <p className="font-bold">Patient Name: <span className="font-medium text-zinc-300">{selectedRx.patientName}</span></p>
                    <p className="font-bold">Contact: <span className="font-medium text-zinc-300">{selectedRx.phone} | {selectedRx.email}</span></p>
                  </div>

                  {/* Status Selection */}
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold">Update Dispatch Status:</label>
                    <select
                      value={editStatus}
                      onChange={(e) => setEditStatus(e.target.value as PrescriptionRequest['status'])}
                      className="p-2.5 rounded bg-zinc-900 border border-zinc-800 text-xs focus:ring-1 focus:ring-teal-400 focus:outline-none"
                    >
                      <option value="Pending">Pending Review</option>
                      <option value="Reviewing">Reviewing Medical History</option>
                      <option value="Preparing">Preparing & Dispensing</option>
                      <option value="Ready for Collection">Ready for Collection</option>
                      <option value="Out for Delivery">Out for Delivery (With Michael)</option>
                      <option value="Completed">Completed & Handed Over</option>
                      <option value="Action Required">Action Required (Contact Patient)</option>
                    </select>
                  </div>

                  {/* Notes Area */}
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold">Clinical/Dispatch Notes for Patient:</label>
                    <textarea
                      rows={3}
                      value={editNotes}
                      onChange={(e) => setEditNotes(e.target.value)}
                      placeholder="e.g. Your medication is dispensed and is in safety bay 4. Or Michael Thompson has safely loaded it onto the delivery van."
                      className="p-2.5 rounded bg-zinc-900 border border-zinc-800 text-xs focus:ring-1 focus:ring-teal-400 focus:outline-none"
                    />
                  </div>

                  {/* Save button and delete button */}
                  <div className="flex gap-2.5 pt-2">
                    <button
                      onClick={() => handleUpdateRx(selectedRx.id)}
                      className={`flex-1 py-2.5 rounded font-extrabold text-xs shadow flex items-center justify-center gap-1.5 ${
                        highContrast
                          ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                          : 'bg-teal-600 text-white hover:bg-teal-700'
                      }`}
                      id="save-rx-status-btn"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save Patient Status
                    </button>
                    
                    <button
                      onClick={() => handleDeleteRx(selectedRx.id)}
                      className="px-3 py-2.5 rounded font-bold text-xs bg-red-950 text-red-400 border border-red-900 hover:bg-red-900 hover:text-white"
                      id="delete-rx-btn"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 rounded-2xl border border-dashed border-zinc-800 text-center bg-zinc-950/45" id="rx-editor-placeholder">
                <p className="text-xs text-zinc-500 leading-relaxed">
                  Select any prescription order from the queue to manage its workflow, edit dispatch notes, or trigger doorstep delivery updates.
                </p>
              </div>
            )}

            {/* Inquiries / Contact Messages Dashboard */}
            <div className={`p-6 rounded-2xl border ${
              highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-zinc-800 bg-zinc-950 text-white'
            }`} id="pharmacist-messages-box">
              <h4 className="text-xs font-black uppercase tracking-wider text-teal-400 mb-4 flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Patient Messages Panel ({messages.length})
              </h4>

              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1" id="pharmacist-messages-list">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    onClick={() => {
                      setSelectedMessage(msg);
                      setReplyText(msg.replyText || '');
                    }}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition ${
                      selectedMessage?.id === msg.id
                        ? 'border-teal-500 bg-zinc-900'
                        : 'border-zinc-900 bg-zinc-950 hover:border-zinc-800'
                    }`}
                    id={`message-row-${msg.id}`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold text-zinc-200">{msg.name}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${
                        msg.replied ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
                      }`}>
                        {msg.replied ? 'Answered' : 'New'}
                      </span>
                    </div>
                    <p className="font-semibold text-zinc-300 text-[11px] truncate">{msg.subject}</p>
                    <p className="text-zinc-400 text-[11px] line-clamp-2 mt-1 italic">"{msg.message}"</p>
                  </div>
                ))}
              </div>

              {/* Message Reply Form */}
              {selectedMessage && (
                <div className="mt-4 pt-4 border-t border-zinc-900 space-y-3" id="message-reply-container">
                  <div className="text-[11px] space-y-0.5 text-zinc-300">
                    <p className="font-bold">Subject: <span className="font-medium">{selectedMessage.subject}</span></p>
                    <p className="font-bold">Patient Question: <span className="font-medium italic">"{selectedMessage.message}"</span></p>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-[11px] font-bold">Write Your Professional Reply:</label>
                    <textarea
                      rows={3}
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="e.g. Hello Ronald, yes we do have flu jabs available on walk-in this Saturday! Feel free to stop by anytime between 9 AM and 1 PM."
                      className="p-2.5 rounded bg-zinc-900 border border-zinc-800 text-xs focus:ring-1 focus:ring-teal-400 focus:outline-none"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => handleReplyMessage(selectedMessage.id)}
                      className={`flex-1 py-2 rounded font-extrabold text-[11px] flex items-center justify-center gap-1 transition ${
                        highContrast
                          ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                          : 'bg-teal-600 text-white hover:bg-teal-700'
                      }`}
                      id="save-message-reply-btn"
                    >
                      <Save className="w-3 h-3" />
                      Save & Send Reply
                    </button>
                    <button
                      onClick={() => setSelectedMessage(null)}
                      className="px-2 py-2 rounded font-bold text-[11px] bg-zinc-800 text-zinc-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
