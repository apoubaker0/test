import React from 'react';
import { motion } from 'motion/react';
import { 
  Truck, CheckCircle, Clock, MapPin, Phone, ShieldCheck, AlertCircle, HeartHandshake
} from 'lucide-react';
import { staffData } from '../data/pharmacyData';

interface DeliveryProps {
  setActiveTab: (tab: string) => void;
  highContrast: boolean;
  textSize: string;
}

export default function Delivery({ setActiveTab, highContrast, textSize }: DeliveryProps) {
  const driver = staffData.find(s => s.role.includes('Delivery')) || staffData[2];

  return (
    <section 
      className={`w-full py-12 sm:py-16 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-white'
      }`}
      id="delivery-section"
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12" id="delivery-header">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide inline-block mb-3 ${
            highContrast ? 'bg-yellow-400 text-black' : 'bg-emerald-100 text-emerald-800'
          }`}>
            Free Local Home Delivery
          </span>
          <h2 className={`font-sans tracking-tight ${
            textSize === 'xlarge' ? 'text-4xl font-black' : textSize === 'large' ? 'text-3xl font-extrabold' : 'text-3xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
            Medication Delivered with Patience & Care
          </h2>
          <p className={`mt-3 ${
            textSize === 'xlarge' ? 'text-lg' : 'text-sm sm:text-base'
          } ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
            We deliver prescriptions free of charge to patients across local Manchester neighborhoods who cannot easily visit us in person.
          </p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start" id="delivery-grid">
          
          {/* Missed Delivery Guarantee / Care Model (Left side - 7 Columns) */}
          <div className="lg:col-span-7 space-y-6" id="delivery-commitments-block">
            
            <div className={`p-6 sm:p-8 rounded-3xl border-2 ${
              highContrast 
                ? 'border-yellow-400 bg-zinc-950 text-white' 
                : 'border-emerald-100 bg-emerald-50/20 text-slate-800'
            }`} id="delivery-promise-card">
              <h3 className="text-lg font-extrabold flex items-center gap-2 text-emerald-950 dark:text-yellow-300">
                <HeartHandshake className="w-5 h-5 text-emerald-600 dark:text-yellow-400 shrink-0" />
                Our Missed-Delivery Safeguards
              </h3>
              <p className="text-xs mt-2 leading-relaxed opacity-85">
                We understand that missing a medication delivery can be highly distressing. To protect your safety and ensure absolute reliability, we have instituted four concrete delivery rules:
              </p>

              {/* Safeguard Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6" id="delivery-safeguard-grid">
                <div className={`p-4 rounded-xl border ${
                  highContrast ? 'border-zinc-800 bg-black' : 'border-slate-100 bg-white'
                }`}>
                  <div className="flex gap-2 items-center">
                    <span className="text-xs font-black px-2 py-0.5 rounded bg-amber-100 text-amber-800">Rule 1</span>
                    <h4 className="text-xs font-bold">Pre-Delivery Calls</h4>
                  </div>
                  <p className="text-[11px] mt-1.5 leading-relaxed opacity-75">
                    Our team will phone you before leaving the pharmacy to confirm you are home and ready to receive your items.
                  </p>
                </div>

                <div className={`p-4 rounded-xl border ${
                  highContrast ? 'border-zinc-800 bg-black' : 'border-slate-100 bg-white'
                }`}>
                  <div className="flex gap-2 items-center">
                    <span className="text-xs font-black px-2 py-0.5 rounded bg-amber-100 text-amber-800">Rule 2</span>
                    <h4 className="text-xs font-bold">Patient Door Waiting</h4>
                  </div>
                  <p className="text-[11px] mt-1.5 leading-relaxed opacity-75">
                    Our drivers wait at least 3-5 minutes, allowing you plenty of time to safely reach the door. We never rush.
                  </p>
                </div>

                <div className={`p-4 rounded-xl border ${
                  highContrast ? 'border-zinc-800 bg-black' : 'border-slate-100 bg-white'
                }`}>
                  <div className="flex gap-2 items-center">
                    <span className="text-xs font-black px-2 py-0.5 rounded bg-amber-100 text-amber-800">Rule 3</span>
                    <h4 className="text-xs font-bold">No Exposed Drops</h4>
                  </div>
                  <p className="text-[11px] mt-1.5 leading-relaxed opacity-75">
                    We never leave prescriptions unattended on porches or doormats. Items are delivered hand-to-hand or returned safely.
                  </p>
                </div>

                <div className={`p-4 rounded-xl border ${
                  highContrast ? 'border-zinc-800 bg-black' : 'border-slate-100 bg-white'
                }`}>
                  <div className="flex gap-2 items-center">
                    <span className="text-xs font-black px-2 py-0.5 rounded bg-amber-100 text-amber-800">Rule 4</span>
                    <h4 className="text-xs font-bold">Free Redelivery Slot</h4>
                  </div>
                  <p className="text-[11px] mt-1.5 leading-relaxed opacity-75">
                    If we do miss you, we will contact you immediately to schedule a prompt, guaranteed redelivery slot at your convenience.
                  </p>
                </div>
              </div>
            </div>

            {/* Meet the Driver profile */}
            <div className={`p-5 rounded-3xl border-2 flex flex-col sm:flex-row gap-4 items-center sm:items-start ${
              highContrast ? 'border-zinc-800 bg-black text-white' : 'border-slate-100 bg-slate-50/50 text-slate-800'
            }`} id="driver-profile-card">
              {/* Profile Avatar Placeholder */}
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 ${
                highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'
              }`}>
                <Truck className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-bold text-sm">Meet Your Friendly Driver: {driver.name}</h4>
                <p className="text-[11px] font-bold text-teal-700 dark:text-yellow-400">{driver.role}</p>
                <p className="text-xs mt-2 leading-relaxed opacity-85">
                  "{driver.bio}"
                </p>
              </div>
            </div>

          </div>

          {/* Zones, Scheduling and Request Instructions (Right side - 5 Columns) */}
          <div className="lg:col-span-5 space-y-6" id="delivery-zones-block">
            
            {/* Delivery Zones */}
            <div className={`p-6 sm:p-8 rounded-3xl border-2 ${
              highContrast ? 'border-yellow-400 bg-zinc-950 text-white' : 'border-slate-100 bg-white'
            }`}>
              <h3 className="text-sm font-black uppercase tracking-wider opacity-60 flex items-center gap-1.5 mb-4">
                <MapPin className="w-4 h-4 text-teal-600 dark:text-yellow-400" />
                Our Delivery Coverages
              </h3>
              
              <p className="text-xs leading-relaxed">
                We deliver to homes located within a <strong>3-mile radius</strong> of our Manchester storefront. This includes:
              </p>

              <div className="mt-4 space-y-2 text-xs font-bold" id="delivery-zones-list">
                <div className="flex justify-between items-center py-2 border-b border-dashed border-slate-100 dark:border-zinc-800">
                  <span>📍 Rusholme & Anson Road</span>
                  <span className="text-teal-700 dark:text-yellow-400">Within 1 mile</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-dashed border-slate-100 dark:border-zinc-800">
                  <span>📍 Victoria Park & Longsight</span>
                  <span className="text-teal-700 dark:text-yellow-400">Within 1.5 miles</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-dashed border-slate-100 dark:border-zinc-800">
                  <span>📍 Fallowfield & Withington</span>
                  <span className="text-teal-700 dark:text-yellow-400">Within 2.5 miles</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span>📍 Levenshulme & Gorton (West)</span>
                  <span className="text-teal-700 dark:text-yellow-400">Within 3 miles</span>
                </div>
              </div>

              {/* Timing details */}
              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-zinc-800 flex items-start gap-3">
                <Clock className="w-5 h-5 text-teal-600 dark:text-yellow-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold">Delivery Timing Checklist:</h4>
                  <p className="text-[11px] mt-1 text-slate-500 dark:text-zinc-400 leading-relaxed">
                    Prescriptions submitted before 12:00 PM are eligible for <strong>Same-Day Delivery</strong>. Requests sent later are delivered on the next operational business day.
                  </p>
                </div>
              </div>
            </div>

            {/* How to sign up */}
            <div className={`p-6 rounded-3xl border text-center ${
              highContrast ? 'border-zinc-800 bg-black text-white' : 'bg-slate-50 border-slate-100'
            }`}>
              <h4 className="text-xs font-black uppercase tracking-wider opacity-60">Ready to Request Delivery?</h4>
              <p className="text-xs mt-2 leading-relaxed text-slate-600 dark:text-zinc-300">
                It is exceptionally simple. When filling out your order in our online portal, check the box that says <strong>"Please deliver this to my home."</strong>
              </p>
              <button
                onClick={() => setActiveTab('patient-hub')}
                className={`mt-4 px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm transition inline-block ${
                  highContrast
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                    : 'bg-teal-600 text-white hover:bg-teal-700'
                }`}
                id="delivery-tab-cta"
              >
                Go to Repeat Prescription Form
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
