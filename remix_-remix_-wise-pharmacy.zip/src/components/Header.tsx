import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Phone, MapPin, Clock, Accessibility, CheckCircle2, ChevronRight, Menu, X, Shield, Settings2, UserCheck
} from 'lucide-react';
import { openingHours } from '../data/pharmacyData';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  textSize: 'normal' | 'large' | 'xlarge';
  setTextSize: (size: 'normal' | 'large' | 'xlarge') => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  textSize,
  setTextSize,
  highContrast,
  setHighContrast
}: HeaderProps) {
  const [isOpenNow, setIsOpenNow] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAccessibilityMenu, setShowAccessibilityMenu] = useState(false);

  // Determine if open based on Manchester time
  useEffect(() => {
    const checkOpenStatus = () => {
      try {
        // Current local time (adjusted for UK if needed, or based on system)
        const date = new Date();
        const utc = date.getTime() + (date.getTimezoneOffset() * 60000);
        // UK is UTC+0 (BST is UTC+1). The metadata says the local time zone offset is -07:00,
        // let's just calculate based on a standard UK timezone or standard date:
        const day = date.getDay(); // 0 is Sunday, 1-5 weekday, 6 Saturday
        const hour = date.getHours();
        
        if (day === 0) {
          setIsOpenNow(false); // Sunday Closed
        } else if (day === 6) {
          // Saturday 9 AM to 1 PM
          setIsOpenNow(hour >= 9 && hour < 13);
        } else {
          // Weekday 9 AM to 6 PM (18:00)
          setIsOpenNow(hour >= 9 && hour < 18);
        }
      } catch (e) {
        setIsOpenNow(true);
      }
    };
    checkOpenStatus();
    const interval = setInterval(checkOpenStatus, 60000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'services', label: 'Our Services' },
    { id: 'delivery', label: 'Delivery Info' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact & Map' },
    { id: 'patient-hub', label: 'Patient Hub' },
    { id: 'pharmacist-portal', label: 'Pharmacist Portal', isSpecial: true }
  ];

  return (
    <header className={`w-full sticky top-0 z-50 transition-colors duration-300 ${
      highContrast 
        ? 'bg-black border-b-4 border-yellow-400 text-yellow-400' 
        : 'bg-white text-slate-800 shadow-md'
    }`} id="wise-pharmacy-header">
      {/* Upper Announcement & Accessibility Strip */}
      <div className={`w-full py-2 px-4 text-xs ${
        highContrast 
          ? 'bg-yellow-400 text-black border-b border-black' 
          : 'bg-gradient-to-r from-teal-700 via-sky-800 to-teal-800 text-white'
      } flex flex-wrap items-center justify-between gap-2`} id="top-announcement-strip">
        <div className="flex flex-wrap items-center gap-4 text-[11px] sm:text-xs">
          <a 
            href="tel:+441612241878" 
            className="flex items-center gap-1.5 hover:underline focus:outline-2 focus:outline-white py-0.5 rounded"
            id="click-to-call-top"
            aria-label="Call pharmacy at +44 161 224 1878"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="font-semibold">Call Us: 0161 224 1878</span>
          </a>
          <div className="hidden sm:flex items-center gap-1.5" id="opening-hours-header-tag">
            <Clock className="w-3.5 h-3.5" />
            <span>Weekdays: 9am - 6pm | Sat: 9am - 1pm</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className={`inline-block w-2.5 h-2.5 rounded-full ${isOpenNow ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></span>
            <span className="font-medium text-[11px]">
              {isOpenNow ? 'Open Now (Closes at 6:00 PM)' : 'Closed Now (Opens 9:00 AM)'}
            </span>
          </div>
        </div>

        {/* Accessibility Panel Quick Launch */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAccessibilityMenu(!showAccessibilityMenu)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-bold uppercase transition ${
              highContrast 
                ? 'bg-black text-yellow-400 border border-black hover:bg-zinc-900' 
                : 'bg-white/15 text-white hover:bg-white/25 border border-white/20'
            }`}
            aria-label="Toggle accessibility tools"
            aria-expanded={showAccessibilityMenu}
            id="accessibility-settings-toggle"
          >
            <Accessibility className="w-3.5 h-3.5" />
            <span>Accessibility Tools</span>
          </button>
        </div>
      </div>

      {/* Accessibility Sub-Panel (Dropdown/Slide-out) */}
      {showAccessibilityMenu && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`w-full p-4 border-b ${
            highContrast 
              ? 'bg-zinc-900 border-yellow-400 text-yellow-300' 
              : 'bg-slate-50 border-slate-200 text-slate-700'
          } flex flex-col md:flex-row md:items-center md:justify-between gap-4`}
          id="accessibility-config-panel"
        >
          <div className="max-w-2xl">
            <h3 className="font-bold text-sm flex items-center gap-2">
              <Accessibility className="w-4 h-4" />
              Wise Pharmacy Care Accessibility Assistant
            </h3>
            <p className="text-xs mt-1 leading-relaxed">
              We care deeply about serving our entire Manchester community, especially our seniors and visually impaired friends. Please adjust the settings below to make this website easier to read and navigate.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            {/* Text Size Control */}
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider">Text Size:</span>
              <div className="flex items-center bg-white border rounded-md p-0.5 overflow-hidden shadow-sm dark:bg-black dark:border-zinc-700">
                <button
                  onClick={() => setTextSize('normal')}
                  className={`px-3 py-1 text-xs font-bold rounded ${
                    textSize === 'normal'
                      ? (highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600 text-white')
                      : 'text-slate-600 hover:bg-slate-100 dark:text-zinc-400 dark:hover:bg-zinc-800'
                  }`}
                  id="font-size-btn-normal"
                >
                  Standard (A)
                </button>
                <button
                  onClick={() => setTextSize('large')}
                  className={`px-3 py-1 text-sm font-bold rounded ${
                    textSize === 'large'
                      ? (highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600 text-white')
                      : 'text-slate-600 hover:bg-slate-100 dark:text-zinc-400 dark:hover:bg-zinc-800'
                  }`}
                  id="font-size-btn-large"
                >
                  Large (A+)
                </button>
                <button
                  onClick={() => setTextSize('xlarge')}
                  className={`px-3 py-1 text-base font-bold rounded ${
                    textSize === 'xlarge'
                      ? (highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600 text-white')
                      : 'text-slate-600 hover:bg-slate-100 dark:text-zinc-400 dark:hover:bg-zinc-800'
                  }`}
                  id="font-size-btn-xlarge"
                >
                  Extra Large (A++)
                </button>
              </div>
            </div>

            {/* High Contrast Toggle */}
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider">Visual Contrast:</span>
              <button
                onClick={() => setHighContrast(!highContrast)}
                className={`px-4 py-2 text-xs font-bold rounded-md border shadow-sm transition ${
                  highContrast
                    ? 'bg-yellow-400 text-black border-yellow-500 hover:bg-yellow-500'
                    : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50'
                }`}
                id="high-contrast-toggle"
              >
                {highContrast ? '⚡ High Contrast (ON)' : '☀ High Contrast (OFF)'}
              </button>
            </div>
            
            <button 
              onClick={() => setShowAccessibilityMenu(false)}
              className="text-xs hover:underline mt-4 md:mt-0 font-bold self-end md:self-center px-2 py-1 rounded"
              id="accessibility-menu-close"
            >
              Dismiss
            </button>
          </div>
        </motion.div>
      )}

      {/* Main Header / Navigation Area */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex items-center justify-between" id="main-navigation-bar">
        {/* Brand Logo & Title */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer group"
          id="wise-pharmacy-logo-box"
        >
          <div className={`p-2.5 rounded-xl transition ${
            highContrast 
              ? 'bg-yellow-400 text-black' 
              : 'bg-teal-50 text-teal-600 group-hover:bg-teal-100'
          }`}>
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-7 h-7"
            >
              {/* Custom Pharmacy Cross with Heart Interior */}
              <path d="M12 3v18M3 12h18" />
              <circle cx="12" cy="12" r="4" className="stroke-teal-500 fill-white dark:fill-zinc-950" />
            </svg>
          </div>
          <div>
            <h1 className={`font-sans font-black tracking-tight leading-none ${
              highContrast ? 'text-yellow-400 text-2xl' : 'text-slate-950 text-xl sm:text-2xl'
            }`}>
              Wise Pharmacy
            </h1>
            <p className={`text-[10px] sm:text-xs font-semibold tracking-wide uppercase mt-0.5 ${
              highContrast ? 'text-yellow-500' : 'text-teal-700'
            }`}>
              11 Anson Rd, Manchester
            </p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1.5" id="desktop-nav-list" aria-label="Main menu">
          {navItems.map((item) => {
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3.5 py-2.5 rounded-lg text-sm font-bold transition-all relative ${
                  item.isSpecial
                    ? highContrast
                      ? 'border-2 border-dashed border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black ml-4'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 ml-4 flex items-center gap-1.5'
                    : isSelected
                      ? highContrast
                        ? 'bg-yellow-400 text-black'
                        : 'bg-teal-50 text-teal-900 border border-teal-200'
                      : highContrast
                        ? 'text-yellow-400 hover:bg-zinc-900'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
                id={`nav-tab-${item.id}`}
              >
                {item.isSpecial && <UserCheck className="w-3.5 h-3.5 inline" />}
                {item.label}
                {isSelected && !item.isSpecial && !highContrast && (
                  <motion.div
                    layoutId="activeTabUnderline"
                    className="absolute bottom-0 left-3 right-3 h-0.5 bg-teal-600 rounded"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Mobile menu trigger */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`p-2 rounded-lg transition ${
              highContrast 
                ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
            }`}
            aria-label="Toggle mobile menu"
            aria-expanded={mobileMenuOpen}
            id="mobile-menu-trigger"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Dropdown */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className={`lg:hidden border-t px-4 py-3 flex flex-col gap-2 ${
            highContrast 
              ? 'bg-zinc-950 border-yellow-400 text-yellow-400' 
              : 'bg-white border-slate-100 shadow-inner'
          }`}
          id="mobile-nav-panel"
        >
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-4 py-3 rounded-lg text-sm font-bold flex items-center justify-between ${
                item.isSpecial
                  ? highContrast
                    ? 'border border-dashed border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black mt-2'
                    : 'bg-slate-50 text-slate-800 hover:bg-slate-100 mt-2 border border-slate-200'
                  : activeTab === item.id
                    ? highContrast
                      ? 'bg-yellow-400 text-black font-extrabold'
                      : 'bg-teal-50 text-teal-900 border border-teal-100 font-extrabold'
                    : 'hover:bg-slate-50'
              }`}
              id={`mobile-nav-tab-${item.id}`}
            >
              <span className="flex items-center gap-2">
                {item.isSpecial && <UserCheck className="w-4 h-4 text-teal-600" />}
                {item.label}
              </span>
              <ChevronRight className="w-4 h-4 opacity-50" />
            </button>
          ))}
          
          <div className={`mt-3 pt-3 border-t flex flex-col gap-2 text-xs text-slate-500 ${highContrast ? 'border-zinc-800 text-zinc-400' : 'border-slate-100'}`}>
            <p className="font-bold flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-teal-600" />
              11 Anson Rd, Manchester M14 5BY
            </p>
            <p className="font-bold flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              0161 224 1878
            </p>
          </div>
        </motion.div>
      )}
    </header>
  );
}
