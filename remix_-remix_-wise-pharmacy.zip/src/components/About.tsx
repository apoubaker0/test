import React from 'react';
import { motion } from 'motion/react';
import { 
  Building2, Heart, Award, Shield, Check, Quote, Users, HeartHandshake, HelpCircle
} from 'lucide-react';
import { staffData } from '../data/pharmacyData';

interface AboutProps {
  highContrast: boolean;
  textSize: string;
}

export default function About({ highContrast, textSize }: AboutProps) {
  return (
    <section 
      className={`w-full py-12 sm:py-16 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-slate-50/30'
      }`}
      id="about-section"
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Upper Split Block: Story and Core Care Model */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16" id="about-story-container">
          
          {/* Visual Accents or Quote Panel (Left - 5 cols) */}
          <div className="lg:col-span-5" id="about-quote-panel">
            <div className={`p-8 rounded-3xl border-2 relative overflow-hidden flex flex-col justify-between h-full min-h-[320px] ${
              highContrast 
                ? 'border-yellow-400 bg-zinc-950 text-white' 
                : 'border-teal-100 bg-gradient-to-br from-teal-50 to-sky-50 text-slate-800 shadow-sm'
            }`}>
              <div className="absolute top-4 right-4 opacity-15">
                <Quote className="w-20 h-20 text-teal-600 dark:text-yellow-400" />
              </div>
              
              <div className="flex-1 flex flex-col justify-center">
                <span className={`text-[11px] font-black uppercase tracking-wider ${
                  highContrast ? 'text-yellow-400' : 'text-teal-800'
                }`}>
                  Our Guiding Principle
                </span>
                
                <p className={`italic font-sans mt-3 font-medium leading-relaxed ${
                  textSize === 'xlarge' ? 'text-xl' : textSize === 'large' ? 'text-lg' : 'text-base'
                }`}>
                  "A neighborhood pharmacy is not just a dispensary; it is a clinical sanctuary where people seek reassurance, clarity, and care. We treat every patient as our own family, taking the extra time to explain, guide, and protect."
                </p>
                
                <p className="mt-4 font-bold text-xs text-slate-500 dark:text-zinc-400">
                  — Mr. Zahid Hussain, Pharmacy Director
                </p>
              </div>

              {/* Badges strip */}
              <div className="mt-8 pt-4 border-t border-teal-100/50 dark:border-zinc-800 flex flex-wrap gap-4 text-xs font-bold">
                <span className="flex items-center gap-1">
                  🛡 NHS Registered
                </span>
                <span className="flex items-center gap-1">
                  ✓ GPhC Certified
                </span>
              </div>
            </div>
          </div>

          {/* Core Story text (Right - 7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6" id="about-story-text">
            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide self-start ${
              highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-100 text-teal-800'
            }`}>
              Our Roots & Journey
            </span>

            <h2 className={`font-sans tracking-tight leading-tight ${
              textSize === 'xlarge' ? 'text-4xl font-black' : textSize === 'large' ? 'text-3xl font-extrabold' : 'text-3xl font-extrabold'
            } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
              Serving Manchester with Patience and Dignity
            </h2>

            <p className={`leading-relaxed ${
              textSize === 'xlarge' ? 'text-lg' : 'text-sm sm:text-base'
            } ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
              Wise Pharmacy was founded in the heart of Manchester with a singular goal: to restore the personal touch to community pharmacy. As corporate pharmacies become increasingly automated and hurried, we remain steadfast in our commitment to patience. We take pride in never rushing a patient or trivializing a concern.
            </p>

            <p className={`leading-relaxed ${
              textSize === 'xlarge' ? 'text-lg' : 'text-sm sm:text-base'
            } ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
              We work closely with neighboring General Practices to offer integrated digital repeats, seasonal immunization campaigns, and confidential Pharmacy First walk-in consultation pathways. For elders, vulnerable patients, and families, we represent a trustworthy anchor you can speak to face-to-face.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2" id="about-pillars">
              <div className="flex gap-2.5 items-start">
                <div className={`p-1 rounded-full shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600 text-white'}`}>
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold">Absolute Clinical Accuracy</h4>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">Two-step barcode validation and dual-pharmacist dispensing safety.</p>
                </div>
              </div>

              <div className="flex gap-2.5 items-start">
                <div className={`p-1 rounded-full shrink-0 ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600 text-white'}`}>
                  <Check className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold">Eldercare Specialists</h4>
                  <p className="text-[11px] text-slate-500 dark:text-zinc-400 mt-0.5 leading-relaxed">Dedicated support with large labels, dosette systems, and gentle guidance.</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Section divider with title */}
        <div className="text-center max-w-xl mx-auto mb-10" id="team-title-block">
          <h3 className={`font-sans tracking-tight ${
            textSize === 'xlarge' ? 'text-2xl font-black' : 'text-xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-900'}`}>
            Meet Our Dedicated Healthcare Team
          </h3>
          <p className="text-xs mt-1.5 text-slate-500 dark:text-zinc-400 leading-relaxed">
            Highly trained clinical professionals who live locally and understand community health needs inside out.
          </p>
        </div>

        {/* Team Cards Grid (3 Columns) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="team-members-grid">
          {staffData.map((member, index) => (
            <div
              key={index}
              className={`p-6 rounded-2xl border-2 flex flex-col justify-between items-center text-center transition-all ${
                highContrast 
                  ? 'border-zinc-800 bg-black text-white hover:border-yellow-400' 
                  : 'border-slate-100 bg-white hover:shadow-md'
              }`}
              id={`team-member-${index}`}
            >
              <div className="flex flex-col items-center">
                {/* Profile Avatar Frame */}
                <div className={`w-20 h-20 rounded-full mb-4 flex items-center justify-center font-bold text-2xl uppercase shadow-inner ${
                  highContrast 
                    ? 'bg-yellow-400 text-black' 
                    : index === 0 
                      ? 'bg-teal-100 text-teal-800' 
                      : index === 1 
                        ? 'bg-sky-100 text-sky-800' 
                        : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {member.name.split(' ').pop()?.[0] || 'W'}
                </div>

                <h4 className={`text-base font-black ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
                  {member.name}
                </h4>
                
                {member.credentials && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 ${
                    highContrast ? 'bg-zinc-900 text-yellow-300' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {member.credentials}
                  </span>
                )}
                
                <p className={`text-xs font-bold mt-1.5 ${
                  highContrast ? 'text-zinc-400' : 'text-teal-700'
                }`}>
                  {member.role}
                </p>

                <p className={`text-xs mt-4 leading-relaxed text-slate-500 dark:text-zinc-300 ${
                  textSize === 'xlarge' ? 'text-sm' : 'text-xs'
                }`}>
                  {member.bio}
                </p>
              </div>

              {/* Mini Care Badge */}
              <div className="mt-6 pt-4 border-t border-slate-100 w-full dark:border-zinc-800 flex justify-center items-center gap-1.5 text-[10px] font-bold opacity-60">
                <Users className="w-3.5 h-3.5 text-teal-600 dark:text-yellow-400" />
                <span>Wise Pharmacy Community Core</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
