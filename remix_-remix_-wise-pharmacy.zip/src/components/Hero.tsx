import React from 'react';
import { motion } from 'motion/react';
import { 
  Phone, Calendar, Clock, MapPin, Sparkles, CheckCircle, ArrowRight, ShieldCheck, HeartHandshake
} from 'lucide-react';
import { openingHours } from '../data/pharmacyData';

// Dynamic image path from previous output
const heroImageSrc = '/src/assets/images/pharmacy_hero_banner_1784309113442.jpg';

interface HeroProps {
  setActiveTab: (tab: string) => void;
  highContrast: boolean;
  textSize: string;
}

export default function Hero({ setActiveTab, highContrast, textSize }: HeroProps) {
  return (
    <section 
      className={`w-full py-10 sm:py-16 md:py-20 px-4 transition-colors duration-300 relative overflow-hidden ${
        highContrast 
          ? 'bg-black text-white' 
          : 'bg-gradient-to-b from-sky-50 via-white to-sky-50/20'
      }`}
      id="hero-section"
    >
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Text Content Block */}
        <div className="lg:col-span-7 flex flex-col gap-6" id="hero-text-container">
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase flex items-center gap-1.5 ${
              highContrast 
                ? 'bg-yellow-400 text-black' 
                : 'bg-teal-100 text-teal-800'
            }`}>
              <HeartHandshake className="w-3.5 h-3.5" />
              Manchester's Family Pharmacy
            </span>
          </div>

          <h2 className={`font-sans tracking-tight leading-tight ${
            textSize === 'xlarge' 
              ? 'text-4xl sm:text-5xl lg:text-6xl font-black' 
              : textSize === 'large'
                ? 'text-3xl sm:text-4xl lg:text-5xl font-extrabold'
                : 'text-3xl sm:text-4xl lg:text-5xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-900'}`}>
            Warm, Trustworthy Care <br />
            <span className={highContrast ? 'text-white' : 'text-teal-600'}>You Can Truly Rely On</span>
          </h2>

          <p className={`leading-relaxed max-w-xl ${
            textSize === 'xlarge' ? 'text-xl' : textSize === 'large' ? 'text-lg' : 'text-base'
          } ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
            At Wise Pharmacy on Anson Road, we believe pharmacy care is about more than just medicine. We are committed to patience, kindness, and absolute reliability. Our experienced clinical team takes the time to listen and treat you with the absolute dignity you deserve.
          </p>

          {/* Core Trust Reassurance (Counteracting negative reviews with concrete promises) */}
          <div className={`p-4 rounded-xl border flex flex-col sm:flex-row gap-4 items-start ${
            highContrast 
              ? 'border-yellow-400 bg-zinc-950 text-white' 
              : 'border-emerald-100 bg-emerald-50/55 text-slate-800'
          }`} id="trust-guarantees-banner">
            <div className={`p-2 rounded-lg self-start ${highContrast ? 'bg-yellow-400 text-black' : 'bg-emerald-600 text-white'}`}>
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-emerald-950 dark:text-yellow-300">Our Community Promise to You:</h4>
              <ul className="text-xs space-y-1.5 mt-2 font-medium">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-yellow-400 shrink-0" />
                  <span><strong>Zero-Rush Consultations:</strong> We will always answer your health queries patiently.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-yellow-400 shrink-0" />
                  <span><strong>Reliable Deliveries:</strong> Our drivers will ring and wait patiently for you.</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-yellow-400 shrink-0" />
                  <span><strong>NHS Trusted:</strong> Full electronic integration with Manchester NHS GP surgeries.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Quick-Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mt-2">
            <button
              onClick={() => setActiveTab('patient-hub')}
              className={`px-6 py-3.5 rounded-xl font-extrabold text-sm shadow-md flex items-center justify-center gap-2 group transition-all transform hover:-translate-y-0.5 ${
                highContrast 
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                  : 'bg-teal-600 text-white hover:bg-teal-700'
              }`}
              id="hero-order-prescription-btn"
            >
              Order Repeat Prescription
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
            
            <button
              onClick={() => setActiveTab('services')}
              className={`px-6 py-3.5 rounded-xl font-bold text-sm border flex items-center justify-center gap-2 transition-all hover:bg-white/20 ${
                highContrast 
                  ? 'border-white text-white hover:bg-zinc-900' 
                  : 'border-slate-300 text-slate-700 bg-white hover:bg-slate-50 hover:border-slate-400'
              }`}
              id="hero-explore-services-btn"
            >
              Explore Our Services
            </button>
          </div>

          {/* Opening & Contact Snippet */}
          <div className={`mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t ${
            highContrast ? 'border-zinc-800' : 'border-slate-200'
          }`} id="hero-quick-details">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${highContrast ? 'bg-zinc-900 text-yellow-400' : 'bg-slate-100 text-slate-600'}`}>
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider opacity-60">Open Today Until 6:00 PM</p>
                <p className="text-sm font-bold">Weekdays 9:00 - 18:00</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${highContrast ? 'bg-zinc-900 text-yellow-400' : 'bg-slate-100 text-slate-600'}`}>
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider opacity-60">Located at Anson Road</p>
                <p className="text-sm font-bold">11 Anson Rd, Manchester M14 5BY</p>
              </div>
            </div>
          </div>
        </div>

        {/* Hero Visual Block */}
        <div className="lg:col-span-5 relative" id="hero-visual-container">
          {/* Accent decoration */}
          {!highContrast && (
            <>
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-teal-200/50 rounded-full blur-2xl z-0"></div>
              <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-sky-200/40 rounded-full blur-3xl z-0"></div>
            </>
          )}
          
          <div className={`relative rounded-3xl overflow-hidden shadow-xl border-4 ${
            highContrast ? 'border-yellow-400' : 'border-white bg-white'
          }`} id="hero-image-wrapper">
            <img 
              src={heroImageSrc} 
              alt="Inside the welcoming and beautifully lit Wise Pharmacy storefront in Manchester, featuring modern medication displays and professional staff" 
              className="w-full h-[320px] sm:h-[400px] object-cover transition-transform duration-700 hover:scale-105"
              referrerPolicy="no-referrer"
              id="hero-img-element"
            />
            
            {/* Quick Consultation Promo Card Overlay */}
            <div className={`absolute bottom-4 left-4 right-4 p-4 rounded-2xl flex items-center justify-between gap-3 shadow-lg ${
              highContrast 
                ? 'bg-black/90 text-yellow-400 border border-yellow-400' 
                : 'bg-white/95 backdrop-blur-md text-slate-800'
            }`} id="hero-promo-overlay">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl text-white ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600'}`}>
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-teal-800 dark:text-yellow-300">Quick Contact</p>
                  <a href="tel:+441612241878" className="text-sm font-black hover:underline">0161 224 1878</a>
                </div>
              </div>
              <a 
                href="tel:+441612241878" 
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  highContrast 
                    ? 'bg-yellow-400 text-black hover:bg-yellow-500' 
                    : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
                }`}
                id="call-now-hero-overlay"
              >
                Call Now
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
