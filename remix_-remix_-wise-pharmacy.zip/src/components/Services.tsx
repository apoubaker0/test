import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Pill, RefreshCw, Truck, MessageSquareHeart, ShieldAlert, HeartPulse, Check, ChevronDown, ArrowRight, PhoneCall, HelpCircle
} from 'lucide-react';
import { servicesData } from '../data/pharmacyData';
import { PharmacyService } from '../types';

interface ServicesProps {
  setActiveTab: (tab: string) => void;
  highContrast: boolean;
  textSize: string;
}

export default function Services({ setActiveTab, highContrast, textSize }: ServicesProps) {
  const [selectedService, setSelectedService] = useState<string | null>('dispensing');
  const [filterType, setFilterType] = useState<'All' | 'NHS' | 'Private' | 'Free Service'>('All');

  const filteredServices = servicesData.filter(s => 
    filterType === 'All' ? true : s.type === filterType
  );

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Pill':
        return <Pill className="w-6 h-6" />;
      case 'RefreshCw':
        return <RefreshCw className="w-6 h-6" />;
      case 'Truck':
        return <Truck className="w-6 h-6" />;
      case 'MessageSquareHeart':
        return <MessageSquareHeart className="w-6 h-6" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-6 h-6" />;
      case 'HeartPulse':
        return <HeartPulse className="w-6 h-6" />;
      default:
        return <Pill className="w-6 h-6" />;
    }
  };

  const currentServiceObj = servicesData.find(s => s.id === selectedService) || servicesData[0];

  return (
    <section 
      className={`w-full py-12 sm:py-16 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-slate-50/50'
      }`}
      id="services-section"
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12" id="services-header">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide inline-block mb-3 ${
            highContrast ? 'bg-yellow-400 text-black' : 'bg-sky-100 text-sky-800'
          }`}>
            Pharmacy Healthcare & NHS Services
          </span>
          <h2 className={`font-sans tracking-tight ${
            textSize === 'xlarge' ? 'text-4xl font-black' : textSize === 'large' ? 'text-3xl font-extrabold' : 'text-3xl font-extrabold'
          } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
            Comprehensive Healthcare, Locally Dispensed
          </h2>
          <p className={`mt-3 ${
            textSize === 'xlarge' ? 'text-lg' : 'text-sm sm:text-base'
          } ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
            We provide an array of certified NHS and private services. From automatic prescription orders to walk-in consultations, our pharmacists are here with dedicated support.
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8" id="services-filter-bar">
          {(['All', 'NHS', 'Free Service'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-extrabold transition-all ${
                filterType === type
                  ? highContrast
                    ? 'bg-yellow-400 text-black border border-yellow-500'
                    : 'bg-teal-600 text-white shadow-sm'
                  : highContrast
                    ? 'border border-zinc-700 hover:bg-zinc-900 text-yellow-400'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-900'
              }`}
              id={`service-filter-${type}`}
            >
              {type === 'All' ? 'All Services' : type === 'NHS' ? 'NHS Fully-Funded' : 'Free Pharmacy Conveniences'}
            </button>
          ))}
        </div>

        {/* Dynamic Interactive Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="services-grid-container">
          
          {/* Service Cards (Left Col) */}
          <div className="lg:col-span-7 space-y-4" id="services-left-column">
            {filteredServices.map((service) => {
              const isSelected = selectedService === service.id;
              return (
                <div
                  key={service.id}
                  onClick={() => setSelectedService(service.id)}
                  className={`p-5 rounded-2xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? highContrast
                        ? 'border-yellow-400 bg-zinc-950 text-white shadow-lg'
                        : 'border-teal-600 bg-white shadow-lg shadow-teal-500/5'
                      : highContrast
                        ? 'border-zinc-800 bg-black text-zinc-300 hover:border-yellow-400/50'
                        : 'border-slate-100 bg-white hover:border-teal-500/20 hover:shadow-md'
                  }`}
                  id={`service-card-${service.id}`}
                  role="button"
                  aria-pressed={isSelected}
                  tabIndex={0}
                >
                  <div className="flex gap-4 items-start">
                    <div className={`p-3 rounded-xl shrink-0 ${
                      isSelected
                        ? highContrast
                          ? 'bg-yellow-400 text-black'
                          : 'bg-teal-600 text-white'
                        : highContrast
                          ? 'bg-zinc-900 text-yellow-400'
                          : 'bg-slate-100 text-slate-700'
                    }`}>
                      {getIcon(service.iconName)}
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className={`text-base font-extrabold ${
                          isSelected 
                            ? (highContrast ? 'text-yellow-400' : 'text-teal-950') 
                            : (highContrast ? 'text-zinc-200' : 'text-slate-800')
                        }`}>
                          {service.title}
                        </h3>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                          service.type === 'NHS'
                            ? highContrast ? 'bg-yellow-400/25 text-yellow-300 border border-yellow-400/50' : 'bg-blue-50 text-blue-700 border border-blue-100'
                            : highContrast ? 'bg-green-400/25 text-green-300 border border-green-400/50' : 'bg-emerald-50 text-emerald-800 border border-emerald-100'
                        }`}>
                          {service.type}
                        </span>
                      </div>
                      <p className={`text-xs mt-1.5 leading-relaxed ${
                        isSelected 
                          ? (highContrast ? 'text-zinc-300' : 'text-slate-700') 
                          : 'text-slate-500'
                      }`}>
                        {service.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Expanded Service Details Panel (Right Col - Interactive) */}
          <div className="lg:col-span-5 sticky top-28" id="services-details-pane">
            <div className={`p-6 sm:p-8 rounded-3xl border-2 shadow-sm ${
              highContrast 
                ? 'border-yellow-400 bg-zinc-950 text-white' 
                : 'border-slate-100 bg-white'
            }`}>
              {/* Feature Highlight Indicator */}
              <div className="flex items-center gap-2 mb-4">
                <span className={`w-2.5 h-2.5 rounded-full ${highContrast ? 'bg-yellow-400' : 'bg-teal-600'}`}></span>
                <span className="text-[10px] font-black uppercase tracking-wider opacity-60">Service Highlights</span>
              </div>

              <h3 className={`font-sans font-black ${
                textSize === 'xlarge' ? 'text-2xl' : 'text-xl'
              } ${highContrast ? 'text-yellow-400' : 'text-slate-950'}`}>
                {currentServiceObj.title}
              </h3>
              
              <p className={`text-xs mt-3 leading-relaxed ${highContrast ? 'text-zinc-300' : 'text-slate-600'}`}>
                {currentServiceObj.description}
              </p>

              {/* Service Details Check List */}
              <div className="mt-6 space-y-3" id="service-checklists">
                {currentServiceObj.details.map((detail, index) => (
                  <div key={index} className="flex gap-2.5 items-start">
                    <div className={`p-0.5 rounded-full mt-0.5 shrink-0 ${
                      highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-700'
                    }`}>
                      <Check className="w-3.5 h-3.5 font-bold" />
                    </div>
                    <span className="text-xs font-semibold leading-relaxed">
                      {detail}
                    </span>
                  </div>
                ))}
              </div>

              {/* Patient Service Reassurance Banner */}
              <div className={`mt-8 p-4 rounded-2xl border text-xs leading-relaxed flex flex-col gap-2 ${
                highContrast 
                  ? 'bg-black border-zinc-800' 
                  : 'bg-teal-50/40 border-teal-100/60'
              }`}>
                <p className="font-bold flex items-center gap-1 text-teal-950 dark:text-yellow-300">
                  <HelpCircle className="w-4 h-4 shrink-0 text-teal-600 dark:text-yellow-400" />
                  Need more clarity?
                </p>
                <span>
                  Our Lead Pharmacist, Mr. Zahid Hussain, is happy to host an informal review of your medication list. No booking required — just call or drop by.
                </span>
              </div>

              {/* Contextual Action Button */}
              <div className="mt-6">
                {currentServiceObj.id === 'repeat' ? (
                  <button
                    onClick={() => setActiveTab('patient-hub')}
                    className={`w-full py-3 rounded-xl font-bold text-sm shadow flex items-center justify-center gap-2 transition ${
                      highContrast
                        ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                        : 'bg-teal-600 text-white hover:bg-teal-700'
                    }`}
                    id="service-cta-repeat-order"
                  >
                    Open Repeat Prescription Form
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <a
                    href="tel:+441612241878"
                    className={`w-full py-3 rounded-xl font-bold text-sm shadow flex items-center justify-center gap-2 transition ${
                      highContrast
                        ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                        : 'bg-teal-600 text-white hover:bg-teal-700'
                    }`}
                    id="service-cta-call"
                  >
                    <PhoneCall className="w-4 h-4" />
                    Call About This Service (0161 224 1878)
                  </a>
                )}
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
