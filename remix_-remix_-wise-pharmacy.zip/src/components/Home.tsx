import React from 'react';
import { motion } from 'motion/react';
import { 
  Star, Quote, HeartPulse, ShieldCheck, HeartHandshake, CheckCircle2, ChevronRight, PhoneCall, Building2
} from 'lucide-react';
import Hero from './Hero';
import { reviewsData } from '../data/pharmacyData';

interface HomeProps {
  setActiveTab: (tab: string) => void;
  highContrast: boolean;
  textSize: string;
}

export default function Home({ setActiveTab, highContrast, textSize }: HomeProps) {
  return (
    <div className="w-full flex flex-col" id="home-view-wrapper">
      
      {/* 1. Hero Banner Component */}
      <Hero setActiveTab={setActiveTab} highContrast={highContrast} textSize={textSize} />

      {/* 2. Reassurance / Value Statement Strip (Bento-Style Trust Pillars) */}
      <section className={`py-12 px-4 border-t border-b ${
        highContrast ? 'bg-zinc-950 border-zinc-800 text-white' : 'bg-slate-50 border-slate-100'
      }`} id="home-trust-pillars">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-xl mx-auto mb-10">
            <h3 className={`font-sans tracking-tight ${
              textSize === 'xlarge' ? 'text-2xl font-black' : 'text-xl font-extrabold'
            } ${highContrast ? 'text-yellow-400' : 'text-slate-900'}`}>
              Why Manchester Chooses Wise Pharmacy
            </h3>
            <p className="text-xs text-slate-500 dark:text-zinc-400 mt-1 leading-relaxed">
              We focus purely on high-contrast accessibility, safety reviews, and dedicated doorstep clinical delivery.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="trust-pillars-grid">
            
            {/* Pillar 1 */}
            <div className={`p-6 rounded-2xl border ${
              highContrast ? 'border-zinc-800 bg-black' : 'bg-white border-slate-100 shadow-sm'
            }`}>
              <div className={`p-3 rounded-xl inline-block mb-4 ${
                highContrast ? 'bg-zinc-900 text-yellow-400' : 'bg-teal-50/60 text-teal-700'
              }`}>
                <HeartHandshake className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900 dark:text-yellow-300">Absolute Patience & Dignity</h4>
              <p className="text-xs text-slate-600 dark:text-zinc-400 mt-2 leading-relaxed">
                We know managing chronic conditions or sorting multiple pills is complex. Our staff will never speak abruptly or rush you through. Your peace of mind is our focus.
              </p>
            </div>

            {/* Pillar 2 */}
            <div className={`p-6 rounded-2xl border ${
              highContrast ? 'border-zinc-800 bg-black' : 'bg-white border-slate-100 shadow-sm'
            }`}>
              <div className={`p-3 rounded-xl inline-block mb-4 ${
                highContrast ? 'bg-zinc-900 text-yellow-400' : 'bg-teal-50/60 text-teal-700'
              }`}>
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900 dark:text-yellow-300">Robust Missed-Delivery Rule</h4>
              <p className="text-xs text-slate-600 dark:text-zinc-400 mt-2 leading-relaxed">
                No medication left exposed or forgotten. We call you before arrival, knock and wait patiently at your doorstep, and guarantee free redelivery if you were away.
              </p>
            </div>

            {/* Pillar 3 */}
            <div className={`p-6 rounded-2xl border ${
              highContrast ? 'border-zinc-800 bg-black' : 'bg-white border-slate-100 shadow-sm'
            }`}>
              <div className={`p-3 rounded-xl inline-block mb-4 ${
                highContrast ? 'bg-zinc-900 text-yellow-400' : 'bg-teal-50/60 text-teal-700'
              }`}>
                <HeartPulse className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900 dark:text-yellow-300">NHS Fully Integrated (EPS)</h4>
              <p className="text-xs text-slate-600 dark:text-zinc-400 mt-2 leading-relaxed">
                Nominate Wise Pharmacy to automatically request, collect, and prepare repeats from your local Manchester GP. Fully digital, tracked, and secure.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* 3. Patient Reviews & Testimonials section (Directly addresses trust building) */}
      <section className={`py-12 sm:py-16 px-4 transition-colors duration-300 ${
        highContrast ? 'bg-black text-white' : 'bg-white'
      }`} id="testimonials-band">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-xl mx-auto mb-10" id="testimonials-header">
            <span className={`px-2.5 py-1 rounded text-[10px] font-black uppercase tracking-wider inline-block mb-2 ${
              highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-50 text-teal-700'
            }`}>
              Patient Feedback
            </span>
            <h3 className={`font-sans tracking-tight ${
              textSize === 'xlarge' ? 'text-3xl font-black' : 'text-2xl font-extrabold'
            } ${highContrast ? 'text-yellow-400' : 'text-slate-900'}`}>
              What Our Local Manchester Patients Say
            </h3>
            <p className="text-xs text-slate-500 dark:text-zinc-400 mt-1 leading-relaxed">
              We are proud of the bonds we build and are always striving to deliver exceptional clinical service.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="testimonials-grid">
            {reviewsData.map((review) => (
              <div
                key={review.id}
                className={`p-6 rounded-2xl border-2 flex flex-col justify-between ${
                  highContrast ? 'border-zinc-800 bg-zinc-950' : 'border-slate-100 bg-slate-50/40'
                }`}
                id={`review-card-${review.id}`}
              >
                <div>
                  <div className="flex gap-1 mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 stroke-amber-400" />
                    ))}
                  </div>

                  <p className={`italic text-xs leading-relaxed text-slate-700 dark:text-zinc-300`}>
                    "{review.text}"
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-dashed border-slate-200/60 dark:border-zinc-800 flex justify-between items-center text-[10px] font-bold">
                  <div>
                    <p className="text-slate-900 dark:text-yellow-400">{review.author}</p>
                    <p className="text-slate-400 font-medium mt-0.5">{review.date}</p>
                  </div>
                  {review.tag && (
                    <span className={`px-2 py-0.5 rounded ${
                      highContrast ? 'bg-zinc-900 text-yellow-300' : 'bg-white text-teal-800 shadow-sm border border-slate-100'
                    }`}>
                      {review.tag}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 4. Contact / Navigation Prompt Footer Teaser */}
      <section className={`py-12 px-4 text-center text-white ${
        highContrast 
          ? 'bg-zinc-950 border-t-2 border-yellow-400' 
          : 'bg-gradient-to-r from-teal-800 via-sky-900 to-teal-900'
      }`} id="home-footer-teaser">
        <div className="max-w-2xl mx-auto space-y-4">
          <h3 className={`font-sans font-black ${textSize === 'xlarge' ? 'text-2xl' : 'text-xl'}`}>
            Let Us Manage Your Repeats Free Of Charge
          </h3>
          <p className="text-xs opacity-85 leading-relaxed max-w-lg mx-auto">
            Say goodbye to waiting in queues or coordinating with doctor surgeries. Register in our Patient Hub today to request tracked doorstep delivery.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('patient-hub')}
              className={`px-6 py-3 rounded-xl font-black text-xs shadow transition ${
                highContrast
                  ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                  : 'bg-white text-slate-900 hover:bg-slate-100'
              }`}
              id="home-teaser-hub-btn"
            >
              Go to Patient Hub
            </button>
            <button
              onClick={() => setActiveTab('contact')}
              className={`px-6 py-3 rounded-xl font-bold text-xs border border-white/30 hover:bg-white/10 transition`}
              id="home-teaser-contact-btn"
            >
              Find Directions & Contact
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
