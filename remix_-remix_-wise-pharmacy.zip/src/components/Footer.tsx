import React from 'react';
import { 
  ShieldAlert, Shield, Heart, MapPin, Phone, Mail, Clock, Accessibility, ExternalLink, HelpCircle
} from 'lucide-react';
import { openingHours } from '../data/pharmacyData';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  highContrast: boolean;
  textSize: string;
}

export default function Footer({ setActiveTab, highContrast, textSize }: FooterProps) {
  return (
    <footer className={`w-full py-12 px-4 border-t transition-colors duration-300 ${
      highContrast 
        ? 'bg-black border-yellow-400 text-yellow-300' 
        : 'bg-slate-900 text-slate-300 border-zinc-800'
    }`} id="wise-pharmacy-footer">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 mb-12">
        
        {/* Brand Column (5 columns) */}
        <div className="md:col-span-5 space-y-4" id="footer-col-brand">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className={`p-2 rounded-lg ${highContrast ? 'bg-yellow-400 text-black' : 'bg-teal-600/25 text-teal-400'}`}>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2.5" 
                className="w-5 h-5"
              >
                <path d="M12 3v18M3 12h18" />
              </svg>
            </div>
            <h2 className="text-lg font-black text-white">Wise Pharmacy</h2>
          </div>
          
          <p className="text-xs leading-relaxed opacity-80 max-w-sm">
            At Wise Pharmacy, patient care is our sole focus. Nominate us as your Manchester community clinical partner to handle your GP repeats, dispensing, and secure home delivery with empathy and precision.
          </p>

          {/* GPhC / NHS Badges placeholder */}
          <div className="flex flex-wrap items-center gap-4 pt-2" id="regulatory-stamps">
            {/* Custom styled NHS badge */}
            <div className="bg-[#005EB8] text-white font-sans font-bold px-3 py-1 rounded text-[11px] leading-none select-none tracking-tight">
              NHS
            </div>
            {/* GPhC simulated stamp */}
            <div className={`border px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider ${
              highContrast ? 'border-yellow-400 text-yellow-400' : 'border-zinc-700 text-zinc-400'
            }`}>
              Registered Pharmacy ✓
            </div>
          </div>
        </div>

        {/* Quick Links Column (3 columns) */}
        <div className="md:col-span-3 space-y-4" id="footer-col-links">
          <h4 className="text-xs font-black uppercase tracking-wider text-white">Care Directory</h4>
          <ul className="text-xs space-y-2 font-bold" id="footer-nav-list">
            <li>
              <button onClick={() => setActiveTab('home')} className="hover:underline hover:text-white transition">
                Home Homepage
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('services')} className="hover:underline hover:text-white transition">
                Pharmacy Services & Jabs
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('delivery')} className="hover:underline hover:text-white transition">
                Home Delivery Safeguards
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('about')} className="hover:underline hover:text-white transition">
                Our History & Local Team
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('contact')} className="hover:underline hover:text-white transition">
                Location & Map Directions
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('patient-hub')} className="hover:underline hover:text-white transition">
                Repeat Prescriptions Hub
              </button>
            </li>
          </ul>
        </div>

        {/* Local Support snippet (4 columns) */}
        <div className="md:col-span-4 space-y-4" id="footer-col-support">
          <h4 className="text-xs font-black uppercase tracking-wider text-white">Local Manchester Support</h4>
          <div className="space-y-3 text-xs opacity-90" id="footer-support-details">
            <p className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <span>{openingHours.address}</span>
            </p>
            <p className="flex items-start gap-2.5">
              <Phone className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <span>
                <a href={`tel:${openingHours.phone.replace(/ /g, '')}`} className="hover:underline text-white font-extrabold">
                  {openingHours.phone}
                </a>
              </span>
            </p>
            <p className="flex items-start gap-2.5">
              <Mail className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <span className="break-all">{openingHours.email}</span>
            </p>
            <p className="flex items-start gap-2.5">
              <Clock className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <span>Weekdays: 9:00 - 18:00 | Saturday: 9:00 - 13:00</span>
            </p>
          </div>
        </div>

      </div>

      {/* Understrip Legal and Accessibility Info */}
      <div className={`pt-6 border-t ${
        highContrast ? 'border-zinc-800' : 'border-zinc-800/80'
      } flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] opacity-75`} id="footer-understrip">
        
        <div className="flex flex-col gap-1 items-center sm:items-start">
          <p>© {new Date().getFullYear()} Wise Pharmacy Manchester. All rights reserved.</p>
          <p className="opacity-60 text-[10px]">
            Designed with absolute WCAG high-contrast accessibility compliance for Manchester patients.
          </p>
        </div>

        <div className="flex flex-wrap gap-4 font-bold" id="footer-regulatory-notices">
          <span className="flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-teal-400" />
            GDPR Compliant Patient Logs
          </span>
          <span className="flex items-center gap-1">
            <Accessibility className="w-3.5 h-3.5 text-teal-400" />
            Screen Reader Optimized
          </span>
        </div>

      </div>
    </footer>
  );
}
