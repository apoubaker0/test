import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Header from './components/Header';
import Home from './components/Home';
import Services from './components/Services';
import Delivery from './components/Delivery';
import About from './components/About';
import ContactLocation from './components/ContactLocation';
import PatientPortal from './components/PatientPortal';
import PharmacistPortal from './components/PharmacistPortal';
import Footer from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [textSize, setTextSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [highContrast, setHighContrast] = useState<boolean>(false);
  const [dbSyncTrigger, setDbSyncTrigger] = useState<number>(0);

  const triggerDatabaseSync = () => {
    setDbSyncTrigger(prev => prev + 1);
  };

  const renderActiveSection = () => {
    switch (activeTab) {
      case 'home':
        return <Home setActiveTab={setActiveTab} highContrast={highContrast} textSize={textSize} />;
      case 'services':
        return <Services setActiveTab={setActiveTab} highContrast={highContrast} textSize={textSize} />;
      case 'delivery':
        return <Delivery setActiveTab={setActiveTab} highContrast={highContrast} textSize={textSize} />;
      case 'about':
        return <About highContrast={highContrast} textSize={textSize} />;
      case 'contact':
        return <ContactLocation highContrast={highContrast} textSize={textSize} onNewMessageSubmitted={triggerDatabaseSync} />;
      case 'patient-hub':
        return <PatientPortal highContrast={highContrast} textSize={textSize} onNewPrescriptionSubmitted={triggerDatabaseSync} />;
      case 'pharmacist-portal':
        return <PharmacistPortal highContrast={highContrast} textSize={textSize} refreshTrigger={dbSyncTrigger} />;
      default:
        return <Home setActiveTab={setActiveTab} highContrast={highContrast} textSize={textSize} />;
    }
  };

  const getGlobalFontSizeClass = () => {
    if (textSize === 'xlarge') return 'prose-xl text-lg sm:text-xl';
    if (textSize === 'large') return 'prose-lg text-base sm:text-lg';
    return 'text-xs sm:text-sm';
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between font-sans transition-colors duration-300 ${
      highContrast 
        ? 'bg-black text-white selection:bg-yellow-400 selection:text-black' 
        : 'bg-[#fafbfe] text-slate-800'
    } ${getGlobalFontSizeClass()}`} id="wise-pharmacy-app-root">
      
      {/* Dynamic Accessible Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        textSize={textSize}
        setTextSize={setTextSize}
        highContrast={highContrast}
        setHighContrast={setHighContrast}
      />

      {/* Main Content Area with Fluid Transitions */}
      <main className="flex-grow w-full" id="wise-pharmacy-main-content">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="w-full"
            id={`main-animation-wrapper-${activeTab}`}
          >
            {renderActiveSection()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Trust-Focused Footing */}
      <Footer
        setActiveTab={setActiveTab}
        highContrast={highContrast}
        textSize={textSize}
      />
    </div>
  );
}
